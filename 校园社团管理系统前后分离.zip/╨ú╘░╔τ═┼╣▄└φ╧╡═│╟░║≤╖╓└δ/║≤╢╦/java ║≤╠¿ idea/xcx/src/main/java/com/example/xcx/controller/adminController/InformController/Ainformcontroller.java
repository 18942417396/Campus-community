package com.example.xcx.controller.adminController.InformController;

import com.example.xcx.controller.shetuanController.STimelineController;
import com.example.xcx.entity.Active;
import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.*;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/admin")
public class Ainformcontroller {

    @Autowired
    HttpServletRequest request;

    @Autowired
    ApplyRepository applyRepository;
    @Autowired
    NewsRepository newsRepository;
    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    ActiveRepository activeRepository;

    @Autowired
    InformRepository informRepository;

    @ModelAttribute("vList")
    public List<String> getVList(){
        ArrayList<String> vList = new ArrayList<>();
        vList.add("社团通知");
        vList.add("社团简介");
        vList.add("社团章程");
        vList.add("社团招新");

        return  vList;
    }

    //    社团管理通知列表
    @GetMapping("/inform/index")
    public String informindexget(@ModelAttribute("myuser")Shetuan myuser, Model model){

        List<Inform> informs = informRepository.findByOrderByWritetimeDesc();

        model.addAttribute("Informs",informs);

        return "/admin/inform/inform-list";
    }

    //   修改咨询通知信息
    @GetMapping("/inform/index/update/{id}")
    public String informupdateget(@ModelAttribute("Inform") Inform inform, Model model, @PathVariable("id")int id){

        Inform inform1= informRepository.findById(id).orElseThrow();

        JSONArray jsonArray = JSONArray.fromObject(inform1.getPictures());

        model.addAttribute("inform",inform1);
        model.addAttribute("jsonArray",jsonArray);
        model.addAttribute("thispictures",inform1.getPictures());


        return "/admin/inform/inform-list-update";
    }

    @PostMapping("/inform/index/update/{id}")
    public String informupdatepost(@RequestParam(value = "picturefile",required = false) MultipartFile[] files, @ModelAttribute("Inform") Inform inform, Model model, @PathVariable("id")int id){

        System.out.println("my pictures"+files);
        System.out.println("length"+files.length+files.toString().length());
        System.out.println("firstname"+files[0].getOriginalFilename());
        Inform nowinform = informRepository.findById(id).orElseThrow();
        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";

        if (files.length==0 || files[0].getOriginalFilename().isEmpty() || files==null || files.toString().length()==0 ){
            System.out.println("文化上传失败!");
            inform.setPictures(nowinform.getPictures());

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
                File fileDir = UploadUtils.getImgDirFile();
                // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
                //  System.out.println(fileDir.getAbsolutePath());

                try {

                    System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                    // 构建真实的文件路径
                    File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                    System.out.println(newFile);
                    // 上传图片到 -》 “绝对路径”
                    files[i].transferTo(newFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();


            inform.setPictures(listjson);

        }


        informRepository.save(inform);

        return "redirect:/admin/admin/inform/index";
    }

    //    删除咨询通知
    @GetMapping("/inform/index/delete/{id}")
    public String informdeleteget(Model model, @PathVariable("id")int id){

        informRepository.deleteById(id);


        return "redirect:/admin/admin/inform/index";
    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }
}
