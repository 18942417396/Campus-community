package com.example.xcx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XcxApplication {

    public static void main(String[] args) {
        SpringApplication.run(XcxApplication.class, args);
    }

}
