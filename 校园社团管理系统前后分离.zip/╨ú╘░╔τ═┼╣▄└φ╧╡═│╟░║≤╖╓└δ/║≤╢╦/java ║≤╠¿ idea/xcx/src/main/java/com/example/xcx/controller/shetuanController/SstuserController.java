package com.example.xcx.controller.shetuanController;


import com.example.xcx.entity.*;
import com.example.xcx.repository.*;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

//社团人员管理
@Controller
@SessionAttributes("myuser")
@RequestMapping("/admin/shetuan")
public class SstuserController {

    @Autowired
    InformRepository informRepository;

    @Autowired
    InformfankuiRepository informfankuiRepository;

    @Autowired
    NewsRepository newsRepository;

    @Autowired
    ApplyRepository applyRepository;

    @Autowired
    STUSRepository stusRepository;

    @Autowired
    UserRepository userRepository;

    @GetMapping("/stzx/stuser/list")
    public String stzxlistdetailfalseget(Model model,@ModelAttribute("myuser")Shetuan shetuan){


        List<STUS> stuses = stusRepository.findByStidOrderByWritetimeDesc(shetuan.getId());

        List<User> users = new ArrayList<>();

        for (var i= 0;i<stuses.size();i++){

            User user = userRepository.findFirstByUsername(stuses.get(i).getUsername());
            users.add(user);

        }

        model.addAttribute("users",users);
        model.addAttribute("stuses",stuses);

        return "shetuan/sz/sz-stusergl";
    }

//    删除社团人员信息
    @GetMapping("/stzx/stuser/delete/{id}")
    public String stzxstuserdeleteget(Model model,@PathVariable("id")int id){

        STUS stus = stusRepository.findById(id).orElseThrow();

        stusRepository.deleteById(id);


        News news = new News();

        news.setUsername(stus.getUsername());
        news.setTopic("被移出通知！");
        news.setMain_text("您已被社团移出社团人员名单！如有疑问请联系社团负责人");
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);


        return "redirect:/admin/shetuan/stzx/stuser/list";
    }

}
