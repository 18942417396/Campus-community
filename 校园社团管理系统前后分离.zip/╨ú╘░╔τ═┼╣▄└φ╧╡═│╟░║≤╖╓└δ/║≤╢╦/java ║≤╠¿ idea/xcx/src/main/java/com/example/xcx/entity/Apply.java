package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
public class Apply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String username;

    private String name;
    private String sex;
    private String mianmao;
    private String job;
    private String introduce;
    private String pictures;
    private Timestamp writetime;
    private int stid;
    private int status;
//    0未处理，1已同意加入，2不同意加入

    public Apply(){
        //         每次post请求构造的时候会创建当前时间
        this.writetime = new Timestamp(System.currentTimeMillis());
    }

}
