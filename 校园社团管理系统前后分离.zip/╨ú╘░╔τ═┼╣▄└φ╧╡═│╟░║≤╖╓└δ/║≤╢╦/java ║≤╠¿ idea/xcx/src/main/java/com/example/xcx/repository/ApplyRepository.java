package com.example.xcx.repository;

import com.example.xcx.entity.Apply;
import com.example.xcx.entity.Inform;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ApplyRepository extends CrudRepository<Apply, Integer> {

//    后台社团管理端，招新申请列表查询
    List<Apply> findByStatusAndStidOrderByWritetime(int status,int stid);


}
