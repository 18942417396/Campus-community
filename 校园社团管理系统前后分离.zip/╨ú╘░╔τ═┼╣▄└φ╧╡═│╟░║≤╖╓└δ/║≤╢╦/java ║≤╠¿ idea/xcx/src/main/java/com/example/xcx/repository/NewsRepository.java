package com.example.xcx.repository;

import com.example.xcx.entity.Inform;
import com.example.xcx.entity.News;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface NewsRepository extends CrudRepository<News, Integer> {

//    客户端小程序页面，查找消息通知
    List<News> findByUsernameAndStatus(String username , int status);

//    我的消息通知
    List<News> findByUsernameOrderByWritetimeDesc(String username);

}
