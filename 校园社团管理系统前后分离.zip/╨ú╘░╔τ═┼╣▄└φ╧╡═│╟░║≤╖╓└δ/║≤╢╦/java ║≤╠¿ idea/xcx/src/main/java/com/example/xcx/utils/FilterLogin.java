package com.example.xcx.utils;

import org.springframework.stereotype.Controller;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@WebFilter("/*")
public class FilterLogin implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;



        String url = request.getRequestURI();
        System.out.println(url);
        Object admin =request.getSession().getAttribute("myuser");
        String logintype = (String) request.getSession().getAttribute("logintype");



        if (url.contains("/WEIXINlogin")){
            filterChain.doFilter(request,response);
            return;
        }

        if (url.contains("/user") || url.contains("/out") || url.contains("/welcome")){
            filterChain.doFilter(request,response);
            return;
        }

        if (url.contains("/login") || url.contains("/Slogin") || url.contains("/Alogin") || url.contains("/register") || url.contains("/index") ){
            filterChain.doFilter(request,response);
            return;
        }

        if (url.contains("/js") || url.contains("/img") || url.contains("/css") || url.contains(".css") || url.contains("/static") || url.contains("/layui") || url.contains(".jpeg") ){
            filterChain.doFilter(request,response);
            System.out.println("我的静态资源放行了");
            return;
        }


        if ( admin != null && logintype.equals("社团") && url.contains("/admin/shetuan")  ){
            filterChain.doFilter(request,response);
            return;
        }

        if (admin != null && logintype.equals("后台") && url.contains("/admin/admin")){
            filterChain.doFilter(request,response);
            return;
        }

//        发布通知放行
        if ( admin != null && logintype.equals("社团") && url.contains("tzglpublish")  ){
            filterChain.doFilter(request,response);
            return;
        }


        System.out.println("被拦截了");
        response.sendRedirect("/index");

    }

    @Override
    public void destroy() {

    }
}
