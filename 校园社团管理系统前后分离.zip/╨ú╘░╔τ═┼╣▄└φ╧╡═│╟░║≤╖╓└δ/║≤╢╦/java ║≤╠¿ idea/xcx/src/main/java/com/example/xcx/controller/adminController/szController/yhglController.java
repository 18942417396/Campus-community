package com.example.xcx.controller.adminController.szController;


import com.example.xcx.entity.User;
import com.example.xcx.repository.ShetuanRepository;
import com.example.xcx.repository.UserRepository;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/admin/home")
public class yhglController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    UserRepository userRepository;

    @GetMapping("/yhgl")
    public String yhglget(Model model){

        List<User> users = userRepository.findAll();

        model.addAttribute("users",users);

        return "admin/sz/sz-yhgl";
    }

    @GetMapping("/yhgl/update/{id}")
    public String yhglupdateget(@ModelAttribute("User")User user, Model model, @PathVariable("id")int id){

        User user1= userRepository.findById(id).orElseThrow();

        model.addAttribute("user",user1);

        return "admin/sz/sz-yhgl-update";
    }

    @PostMapping("/yhgl/update/{id}")
    public String yhglupdatepost(@RequestParam(value = "pictures",required = false) MultipartFile file, @ModelAttribute("User")User user, Model model, @PathVariable("id")int id){

        User nowuser = userRepository.findById(id).orElseThrow();


        System.out.println("文件名字"+file.getOriginalFilename());

        if (file == null || file.toString().length() ==0 || file.isEmpty()){
            System.out.println("文化上传失败!");
            user.setFaceimg(nowuser.getFaceimg());

        }else {

            String filename = file.getOriginalFilename();
            String mysqlfilename = "http://localhost:8080/static/face_img/"+filename ;
            // 存放上传图片的文件夹
            File fileDir = UploadUtils.getImgDirFile();
            // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径

            try {

                System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                // 构建真实的文件路径
                File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                System.out.println(newFile);
                // 上传图片到 -》 “绝对路径”
                file.transferTo(newFile);

            } catch (IOException e) {
                e.printStackTrace();
            }


            user.setFaceimg(mysqlfilename);

        }


        userRepository.save(user);

        return "redirect:/admin/admin/home/yhgl";
    }


    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }

    @GetMapping("/yhgl/delete/{id}")
    public String yhgldeleteget(Model model, @PathVariable("id")int id){

        userRepository.deleteById(id);

        return "redirect:/admin/admin/home/yhgl";
    }

}
