package com.example.xcx.controller.shetuanController;


import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Informfankui;
import com.example.xcx.entity.News;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.InformRepository;
import com.example.xcx.repository.InformfankuiRepository;
import com.example.xcx.repository.NewsRepository;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Controller
@SessionAttributes("myuser")
@RequestMapping("/admin/shetuan")
public class STimelineController {

    @Autowired
    InformRepository informRepository;

    @Autowired
    InformfankuiRepository informfankuiRepository;

    @Autowired
    NewsRepository newsRepository;

    @ModelAttribute("vList")
    public List<String> getVList(){
        ArrayList<String> vList = new ArrayList<>();
        vList.add("社团通知");
        vList.add("社团简介");
        vList.add("社团章程");
        vList.add("社团招新");

        return  vList;
    }


    @GetMapping("/home")
    public String homeget(){

        return "shetuan/Sindex";
    }
//    社团管理通知列表
@GetMapping("/tzgl")
public String tzglget(@ModelAttribute("myuser")Shetuan myuser, Model model){

    List<Inform> informs = informRepository.findByStidAndStatusOrderByWritetimeDesc(myuser.getId(),0);

    model.addAttribute("Informs",informs);

    return "/shetuan/tzglzx/tzglzx-tzgl";
}

//    社团通知发布
    @GetMapping("/tzglpublish")
    public String tzglpublishget(@ModelAttribute("Inform")Inform Inform, Model model){


        System.out.println("look this" +getVList());

        model.addAttribute("vList",getVList());


        return "/shetuan/tzglzx/tzglzx-tzglpublish";
    }
    @PostMapping("/tzglpublish")
    public String tzglpublishpost(@RequestParam(value = "picture",required = false)MultipartFile[] files, @ModelAttribute("Inform")Inform Inform, @ModelAttribute("myuser")Shetuan myuser){

        System.out.println("进来了上传图片接口");
        System.out.println(files);

        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";


        if (files.length==0){
            System.out.println("文化上传失败!");

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
            File fileDir = UploadUtils.getImgDirFile();
            // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
            //  System.out.println(fileDir.getAbsolutePath());

            try {

                System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                // 构建真实的文件路径
                File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                System.out.println(newFile);
                // 上传图片到 -》 “绝对路径”
                files[i].transferTo(newFile);

            } catch (IOException e) {
                e.printStackTrace();
            }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();
            System.out.println("i put" + listjson);

        }
        System.out.println(Inform);
        Inform.setStid(myuser.getId());
        Inform.setPictures(listjson);
        informRepository.save(Inform);

        return "redirect:/admin/shetuan/tzgl";
    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }



//   修改咨询通知信息
@GetMapping("/tzgl/update/{id}")
public String tzglupdateget(@ModelAttribute("Inform")Inform inform, Model model, @PathVariable("id")int id){

    Inform inform1= informRepository.findById(id).orElseThrow();

    JSONArray jsonArray = JSONArray.fromObject(inform1.getPictures());

    model.addAttribute("inform",inform1);
    model.addAttribute("jsonArray",jsonArray);
    model.addAttribute("thispictures",inform1.getPictures());


    return "shetuan/tzglzx/tzglzx-tzgl-update";
}

    @PostMapping("/tzgl/update/{id}")
    public String tzglupdatepost(@RequestParam(value = "picturefile",required = false) MultipartFile[] files, @ModelAttribute("Inform") Inform inform, Model model, @PathVariable("id")int id){

        System.out.println("my pictures"+files);
        System.out.println("length"+files.length+files.toString().length());
        System.out.println("firstname"+files[0].getOriginalFilename());
        Inform nowinform = informRepository.findById(id).orElseThrow();
        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";

        if (files.length==0 || files[0].getOriginalFilename().isEmpty() || files==null || files.toString().length()==0 ){
            System.out.println("文化上传失败!");
            inform.setPictures(nowinform.getPictures());

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
                File fileDir = UploadUtils.getImgDirFile();
                // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
                //  System.out.println(fileDir.getAbsolutePath());

                try {

                    System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                    // 构建真实的文件路径
                    File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                    System.out.println(newFile);
                    // 上传图片到 -》 “绝对路径”
                    files[i].transferTo(newFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();


            inform.setPictures(listjson);

        }


        informRepository.save(inform);

        return "redirect:/admin/shetuan/tzgl";
    }

//    删除咨询通知
@GetMapping("/tzgl/delete/{id}")
public String tzgldeleteget(Model model, @PathVariable("id")int id){

    informRepository.deleteById(id);


    return "redirect:/admin/shetuan/tzgl";
}

//反馈通知查询

@GetMapping("/tzgl/fankui")
public String tzglfankuiget(@ModelAttribute("myuser")Shetuan myuser,Model model){

        List<Informfankui> informfankuis = informfankuiRepository.findByStidOrderByWritetimeDesc(myuser.getId());

        model.addAttribute("informfankuis",informfankuis);

    return "shetuan/tzglzx/tzglzx-tzglfankui";
}

//反馈通知原文
    @GetMapping("/tzgl/fankui/detail/{id}")
    public String tzglfankuidetailget(@PathVariable("id")int id,Model model){


        Inform inform = informRepository.findById(id).orElseThrow();

        model.addAttribute("inform",inform);

        List<String> pictures = JSONArray.fromObject(inform.getPictures());

        model.addAttribute("pictures",pictures);

        return "shetuan/tzglzx/tzglzx-tzglfankui-detail";
    }

//    反馈内容填写
    @GetMapping("/tzgl/fankui/update/{id}")
    public String fankuiupdateget(@PathVariable("id")int id,Model model){

        model.addAttribute("id",id);
        return "shetuan/tzglzx/tzglzx-tzglfankui-update";
    }

    @PostMapping("/tzgl/fankui/update/{id}")
    public String fankuiupdatepost(@PathVariable("id")int id,Model model,@RequestParam("liyou")String liyou){


        Informfankui informfankui = informfankuiRepository.findById(id).orElseThrow();


        News news = new News();

        news.setUsername(informfankui.getUsername());
        news.setTopic("反馈处理结果！");
        news.setMain_text("结果为:"+liyou);
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);

        informfankui.setStatus(1);
        informfankuiRepository.save(informfankui);

        return "redirect:/admin/shetuan/tzgl/fankui";
    }



}
