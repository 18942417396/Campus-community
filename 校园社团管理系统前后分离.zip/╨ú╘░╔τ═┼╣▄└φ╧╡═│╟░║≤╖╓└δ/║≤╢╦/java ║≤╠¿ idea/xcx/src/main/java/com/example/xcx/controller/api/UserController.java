package com.example.xcx.controller.api;

import com.example.xcx.entity.*;
import com.example.xcx.repository.*;
import com.example.xcx.utils.Gettoday;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    UserinActiveRepository userinActiveRepository;

    @Autowired
    ActivefankuiRepository activefankuiRepository;

    @Autowired
    InformfankuiRepository informfankuiRepository;

    @Autowired
    InformRepository informRepository;

    @Autowired
    NewsRepository newsRepository;

    @Autowired
    ActiveRepository activeRepository;

    @Autowired
    STUSRepository stusRepository;

//    登录
    @PostMapping("/login")
    public String userloginpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        String username = map.get("username").toString();
        String password = map.get("password").toString();

        User userisexit =  userRepository.findFirstByUsernameAndPassword(username,password);
        if (userisexit!=null){
            String userjson = String.valueOf(JSONObject.fromObject (userisexit));

            News news = new News();

            news.setUsername((String) map.get("username"));
            news.setTopic("登录通知");
            news.setMain_text("登录成功！~");
            news.setFromusername("系统");
            news.setStatus(0);
            newsRepository.save(news);

            return userjson;


        }else {
            return "fail";
        }


    }

//    注册时候图片上传

    @PostMapping("/faceimg/upload")
    public String index(@RequestParam(value = "file",required = false)MultipartFile file)  {
        System.out.println("进来了上传图片接口");
        System.out.println(file);
        String msg = "";
        if (file.isEmpty()) {
            System.out.println("文化上传失败!");
            return "request fail";
        }else {
            System.out.println("文化上传成功!");
            // 拿到文件名
            String filename = file.getOriginalFilename();
            System.out.println("0"+filename);//获取图片的文件名
            // 存放上传图片的文件夹
            File fileDir = UploadUtils.getImgDirFile();
            // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
            //  System.out.println(fileDir.getAbsolutePath());

            try {
                System.out.println(fileDir.getAbsolutePath());
                System.out.println(File.separator);
                System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                // 构建真实的文件路径
                File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                System.out.println(newFile);
                // 上传图片到 -》 “绝对路径”
                file.transferTo(newFile);
                msg = "上传成功!";

                return "http://localhost:8080/static/face_img/"+filename;
            } catch (IOException  e) {
                e.printStackTrace();
            }



        }

        return "request fail";

    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }

//    注册
    @PostMapping("/register")
    public String userregisterpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);



        String username = map.get("username").toString();


        User userisexit =  userRepository.findFirstByUsername(username);

        if (userisexit !=null){


            return "fail";

        }else {

            User user= new User();
            user.setOpenid(map.get("_openid").toString());
            user.setFaceimg((String) map.get("faceimg"));
            user.setUsername((String) map.get("username"));
            user.setPassword(map.get("password").toString());
            userRepository.save(user);

            String userjson = String.valueOf(JSONObject.fromObject (user));


            News news = new News();

            news.setUsername((String) map.get("username"));
            news.setTopic("注册通知");
            news.setMain_text("您注册的账号已通过，可正常使用~");
            news.setFromusername("系统");
            news.setStatus(0);

            newsRepository.save(news);


            return userjson;


        }




    }

//    个人信息修改
    @PostMapping("/update")
    public String userupdatepost(@RequestBody String jsonString){

            Map map = JSONObject.fromObject(jsonString);

        User userisexit =  userRepository.findFirstByUsername((String) map.get("username"));

        userisexit.setFaceimg((String) map.get("faceimg"));
        userisexit.setUsername((String) map.get("username"));

            userRepository.save(userisexit);

        News news = new News();

        news.setUsername((String) map.get("username"));
        news.setTopic("修改头像昵称通知");
        news.setMain_text("修改头像昵称已通过，可正常使用~");
        news.setFromusername("系统");
        news.setStatus(0);
        newsRepository.save(news);
            return "ok";





    }

//    社团注册申请表提交

    @PostMapping("/shetuanregister")
    public String shetuanregisterpost(@RequestBody String jsonString){
        System.out.println(request.getSession().getId());
        System.out.println(jsonString);
        String _openid = (String) request.getSession().getAttribute("_openid");
        System.out.println(_openid);

        Map map = JSONObject.fromObject(jsonString);

        Shetuan shetuan = new Shetuan();

        Shetuan shetuanpanduan = shetuanRepository.findFirstByShetuanName((String) map.get("shetuanName"));

        if (shetuanpanduan !=null){

            return "thisshetuanexit";

        }else {

            shetuan.setCreate_openid(_openid);
            shetuan.setShetuanName((String) map.get("shetuanName"));
            shetuan.setCreateusername(map.get("username").toString());
            shetuan.setPassword((String) map.get("password"));
            shetuan.setStatus(0);
            shetuan.setIntroduce((String) map.get("introduce"));
            shetuan.setShetuanfaceimg((String) map.get("shetuanfaceimg"));

            shetuanRepository.save(shetuan);


            String shetuanjson = String.valueOf(JSONObject.fromObject (shetuan));
            return shetuanjson;

        }

    }


//    客户端小程序我的页面，查询消息通知

    @PostMapping("/mine/newsget")
    public String minenewsgetpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        List<News> news = newsRepository.findByUsernameAndStatus(map.get("username").toString(),0);


        if (news !=null){

            return "true";

        }else {


            return "false";

        }

    }

//    我的消息通知

    @PostMapping("/grxx/newsget")
    public JSONArray grxxnewsgetpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        List<News> news = newsRepository.findByUsernameOrderByWritetimeDesc(map.get("username").toString());

        JSONArray jsonArray = JSONArray.fromObject(news);

        return jsonArray;



    }


    //    小程序首页查询
@GetMapping("/tzgl")
public JSONArray xcxtzglget(){

    List<Inform> informs = informRepository.findByStatusOrderByWritetimeDesc(0);

    JSONArray array = JSONArray.fromObject(informs);


    return array;
}

    //    小程序社团通知页面查询搜索
    @PostMapping("/tzgl-sttz/search")
    public JSONArray xcxsttzsearchpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        System.out.println("mysearch"+map.get("topic").toString());

        List<Inform> informs = informRepository.findByStatusAndTopicLikeAndTypeOrderByWritetimeDesc(0,"%"+map.get("topic").toString()+"%","社团通知");

        JSONArray array = JSONArray.fromObject(informs);


        return array;
    }

    //    小程序社团简介页面查询搜索
    @PostMapping("/tzgl-stjj/search")
    public JSONArray xcxstjjsearchpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        System.out.println("mysearch"+map.get("topic").toString());

        List<Inform> informs = informRepository.findByStatusAndTopicLikeAndTypeOrderByWritetimeDesc(0,"%"+map.get("topic").toString()+"%","社团简介");

        JSONArray array = JSONArray.fromObject(informs);


        return array;
    }

    //    小程序社团章程页面查询搜索
    @PostMapping("/tzgl-stzc/search")
    public JSONArray xcxstzcsearchpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        System.out.println("mysearch"+map.get("topic").toString());

        List<Inform> informs = informRepository.findByStatusAndTopicLikeAndTypeOrderByWritetimeDesc(0,"%"+map.get("topic").toString()+"%","社团章程");

        JSONArray array = JSONArray.fromObject(informs);


        return array;
    }

    //    小程序社团招新页面查询搜索
    @PostMapping("/tzgl-stzx/search")
    public JSONArray xcxstzxsearchpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        System.out.println("mysearch"+map.get("topic").toString());

        List<Inform> informs = informRepository.findByStatusAndTopicLikeAndTypeOrderByWritetimeDesc(0,"%"+map.get("topic").toString()+"%","社团招新");

        JSONArray array = JSONArray.fromObject(informs);


        return array;
    }

//    小程序咨询通知类详情
@PostMapping("/tzgl/detail")
public JSON xcxtzgldetailpost(@RequestBody String jsonString){


    Map map = JSONObject.fromObject(jsonString);

    Inform inform = informRepository.findById(Integer.parseInt(map.get("id").toString())).orElseThrow();

    JSON json = JSONObject.fromObject(inform);

    return json;
}

//咨询通知反馈提交
@PostMapping("/tzgl/fankui")
public String xcxtzglfankuipost(@RequestBody String jsonString){


    Map map = JSONObject.fromObject(jsonString);

    Informfankui informfankui = new Informfankui();

    informfankui.setStatus(0);
    informfankui.setUsername(map.get("username").toString());
    informfankui.setInformid(Integer.parseInt(map.get("informid").toString()));
    informfankui.setMain_text(map.get("fankui").toString());
    informfankui.setStid(Integer.parseInt(map.get("stid").toString()));

    informfankuiRepository.save(informfankui);


    return "ok";
}

    //活动反馈提交
    @PostMapping("/active/fankui")
    public String xcxactivefankuipost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        Activefankui activefankui = new Activefankui();


        activefankui.setStatus(0);
        activefankui.setUsername(map.get("username").toString());
        activefankui.setActiveid(Integer.parseInt(map.get("activeid").toString()));
        activefankui.setMain_text(map.get("fankui").toString());
        activefankui.setStid(Integer.parseInt(map.get("stid").toString()));

        activefankuiRepository.save(activefankui);


        return "ok";
    }

    //活动报名提交校验
    @PostMapping("/active/baoming/first")
    public String xcxactivebaomingfirstpost(@RequestBody String jsonString){

        Date date = new Date();

        System.out.println(date);

        String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);

        System.out.println(nowTime);

        Timestamp nowTimeTimestamp = Timestamp.valueOf(nowTime);

        Map map = JSONObject.fromObject(jsonString);

        UserinActive userinActive = userinActiveRepository.findFirstByActiveidAndUsername(Integer.parseInt(map.get("id").toString()),map.get("username").toString());

        if (userinActive ==null){
            Active active = activeRepository.findById(Integer.parseInt(map.get("id").toString())).orElseThrow();

            if (nowTimeTimestamp.getTime()> active.getBegintime().getTime()){
                return "above";
            }

            UserinActive userinActive1 = new UserinActive();
            userinActive1.setActiveid(Integer.parseInt(map.get("id").toString()));
            userinActive1.setUsername(map.get("username").toString());
            userinActiveRepository.save(userinActive1);

            News news = new News();

            news.setUsername(map.get("username").toString());
            news.setTopic("活动报名通知！");
            news.setMain_text("报名成功！~");
            news.setFromusername("系统");
            news.setStatus(0);

            newsRepository.save(news);

            return "success";

        }else {
            return "fail";

        }


    }

//    我的页面获取今天的活动

    @PostMapping("/active/mine/today")
    public JSONArray xcxactiveminetodaypost(@RequestBody String jsonString){

        Timestamp[] s = Gettoday.getDateStartAndEnd();

        System.out.println(s[0]+"第二个"+s[1]);
        System.out.println("转化为时间错第一个"+s[0].getTime()+"第二个"+s[1].getTime());

        Map map = JSONObject.fromObject(jsonString);

        List<UserinActive> userinActives = userinActiveRepository.findByUsernameOrderByWritetimeDesc(map.get("username").toString());

        List<Active> actives = new ArrayList<>();
        for (var i =0;i<userinActives.size();i++){

                Active active = activeRepository.findById(userinActives.get(i).getActiveid()).orElseThrow();

                if ( (s[0].getTime()<=active.getBegintime().getTime() && active.getBegintime().getTime() <= s[1].getTime()) ||  (s[0].getTime()<=active.getEndtime().getTime() && active.getEndtime().getTime() <= s[1].getTime())  || (active.getBegintime().getTime() <=s[0].getTime() && s[0].getTime() <= active.getEndtime().getTime() )){
                    actives.add(active);
                }


        }

        JSONArray jsonArray = JSONArray.fromObject(actives);

        return jsonArray;




    }

    //    我的页面我加入的活动

    @PostMapping("/active/mine/all")
    public JSONArray xcxactivemineallpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        List<UserinActive> userinActives = userinActiveRepository.findByUsernameOrderByWritetimeDesc(map.get("username").toString());

        List<Active> actives = new ArrayList<>();
        for (var i =0;i<userinActives.size();i++){

            Active active = activeRepository.findById(userinActives.get(i).getActiveid()).orElseThrow();


                actives.add(active);



        }

        JSONArray jsonArray = JSONArray.fromObject(actives);

        return jsonArray;



    }

//    我的页面我加入社团

    @PostMapping("/st/mine/all")
    public JSONArray xcxstmineallpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        List<STUS> stuses = stusRepository.findByUsernameOrderByWritetimeDesc(map.get("username").toString());


        List<Shetuan> shetuans = new ArrayList<>();
        for (var i=0;i<stuses.size();i++){
            Shetuan shetuan = shetuanRepository.findById(stuses.get(i).getStid()).orElseThrow();
            shetuans.add(shetuan);

        }

        JSONArray jsonArray = JSONArray.fromObject(shetuans);
        return jsonArray;



    }

    //    活动日历

    @PostMapping("/hdrl")
    public JSONArray xcxhdrlpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        List<Active> actives = activeRepository.findByStatusOrderByWritetime(1);

        List<Active> activesfinally = new ArrayList<>();

        for (var i =0;i<actives.size();i++){


            System.out.println(actives.get(i).getBegintime().getTime());
            if ((Long.parseLong(map.get("tstart").toString()) <= actives.get(i).getBegintime().getTime()  &&  actives.get(i).getBegintime().getTime() <= Long.parseLong(map.get("tend").toString())) || (Long.parseLong(map.get("tstart").toString()) <= actives.get(i).getEndtime().getTime()  &&  actives.get(i).getEndtime().getTime() <= Long.parseLong(map.get("tend").toString()))  || ( Long.parseLong(map.get("tstart").toString()) <= actives.get(i).getEndtime().getTime() && Long.parseLong(map.get("tstart").toString()) >= actives.get(i).getBegintime().getTime() )){
                activesfinally.add(actives.get(i));
            }


        }
        JSONArray jsonArray =JSONArray.fromObject(activesfinally);

        return  jsonArray;



    }

//    咨询通知详情查找反馈内容

    @PostMapping("/zxtz/fankui/detail")
    public JSONArray xcxzxtzdetailpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        List<Informfankui> informfankuis = informfankuiRepository.findByInformidOrderByWritetimeDesc(Integer.parseInt(map.get("informid").toString()));

        JSONArray jsonArray = JSONArray.fromObject(informfankuis);
        return jsonArray;



    }

    //    咨询通知详情查找反馈内容

    @PostMapping("/active/fankui/detail")
    public JSONArray xcxacviedetailpost(@RequestBody String jsonString){

        Map map = JSONObject.fromObject(jsonString);

        List<Activefankui> activefankuis = activefankuiRepository.findByActiveidOrderByWritetimeDesc(Integer.parseInt(map.get("activeid").toString()));

        JSONArray jsonArray = JSONArray.fromObject(activefankuis);
        return jsonArray;



    }
}
