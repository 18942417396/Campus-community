package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Data
public class Shetuan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String create_openid;
    private String createusername;
    private String shetuanfaceimg;
    private String shetuanName;
    private String password;
    private String introduce;
    private int status;
//    0未审核，1已注册成功，2禁用

}
