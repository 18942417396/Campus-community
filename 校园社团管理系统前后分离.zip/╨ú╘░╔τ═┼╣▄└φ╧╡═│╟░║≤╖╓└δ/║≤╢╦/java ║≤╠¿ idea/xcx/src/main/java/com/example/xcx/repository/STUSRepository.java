package com.example.xcx.repository;

import com.example.xcx.entity.Apply;
import com.example.xcx.entity.STUS;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface STUSRepository extends CrudRepository<STUS, Integer> {

//后台社团管理社团人员管理
    List<STUS> findByStidOrderByWritetimeDesc(int stid);

//    客户端我的页面查找我加入的社团
List<STUS> findByUsernameOrderByWritetimeDesc(String username);
}
