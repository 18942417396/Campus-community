package com.example.xcx.controller.shetuanController;


import com.example.xcx.controller.adminController.ActiveController.Aactivecontroller;
import com.example.xcx.entity.*;
import com.example.xcx.repository.*;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

//活动控制
@Controller
@SessionAttributes("myuser")
@RequestMapping("/admin/shetuan")
public class SactiveController {

    @Autowired
    InformRepository informRepository;

    @Autowired
    InformfankuiRepository informfankuiRepository;

    @Autowired
    NewsRepository newsRepository;

    @Autowired
    ApplyRepository applyRepository;

    @Autowired
    STUSRepository stusRepository;

    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    ActivefankuiRepository activefankuiRepository;

    @Autowired
    ActiveRepository activeRepository;

    @Autowired
    UserinActiveRepository userinActiveRepository;

    @Autowired
    UserRepository userRepository;

    //    社团活动发布
    @GetMapping("/activepublish")
    public String activepublishget(@ModelAttribute("Inform") Inform Inform, Model model){


        return "/shetuan/active/active-publish";
    }
    @PostMapping("/activepublish")
    public String activepublishpost(@RequestParam(value = "picture",required = false) MultipartFile[] files,@ModelAttribute("Active")Active active, @RequestParam("start")String start ,@RequestParam("end")String end,Model model,@ModelAttribute("myuser")Shetuan shetuan){

        System.out.println("myoublish"+active);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.US);


        LocalDateTime localDate1 = LocalDateTime.parse(start, formatter);
        LocalDateTime localDate2 = LocalDateTime.parse(end, formatter);

        Timestamp starttime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate1));
        Timestamp endtime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate2));

        if ( starttime.getTime() >= endtime.getTime()){

            model.addAttribute("errMsg","起始时间不能大于结束时间");
            return "shetuan/active/active-publish";
        }


        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";


        if (files.length==0){
            System.out.println("文化上传失败!");

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
                File fileDir = STimelineController.UploadUtils.getImgDirFile();
                // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
                //  System.out.println(fileDir.getAbsolutePath());

                try {

                    System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                    // 构建真实的文件路径
                    File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                    System.out.println(newFile);
                    // 上传图片到 -》 “绝对路径”
                    files[i].transferTo(newFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();
            System.out.println("i put" + listjson);

        }
        active.setStid(shetuan.getId());
        active.setBegintime(starttime);
        active.setEndtime(endtime);
        active.setPictures(listjson);
        active.setStatus(0);
        activeRepository.save(active);

        return "redirect:/admin/shetuan/activepublish";
    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }


    //社团活动管理列表
    @GetMapping("/sthdgl/list")
    public String sthdgllistget(Model model,@ModelAttribute("myuser")Shetuan shetuan){

        List<Active> actives = activeRepository.findByStidOrderByWritetime(shetuan.getId());

        model.addAttribute("actives",actives);
        return "shetuan/active/active-list";
    }
//社团活动详情

    @GetMapping("/activegl/detail/{id}")
    public String activedetailglget(@PathVariable("id")int id, Model model){

        Active active = activeRepository.findById(id).orElseThrow();

        Shetuan shetuan = shetuanRepository.findById(active.getStid()).orElseThrow();


        List<String> pictures = JSONArray.fromObject(active.getPictures());
        model.addAttribute("shetuan",shetuan);
        model.addAttribute("active",active);
        model.addAttribute("pictures",pictures);
        return "shetuan/active/active-list-detail";
    }


    @GetMapping("/change/active/{id}")
    public String sthdgllistget(@ModelAttribute("Active")Active active, Model model, @PathVariable("id")int id){

        Active active1= activeRepository.findById(id).orElseThrow();

        JSONArray jsonArray = JSONArray.fromObject(active1.getPictures());

        model.addAttribute("jsonArray",jsonArray);
        model.addAttribute("active",active1);
        model.addAttribute("thispictures",active1.getPictures());

        return "shetuan/active/active-list-detail-update";
    }

    @PostMapping("/change/active/{id}")
    public String sthdgllistpost(@RequestParam(value = "picturefile",required = false) MultipartFile[] files, @ModelAttribute("Active")Active active, Model model, @PathVariable("id")int id,@RequestParam("start")String start ,@RequestParam("end")String end){

        Active active1 = activeRepository.findById(id).orElseThrow();

        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";

        if (files.length==0 || files[0].getOriginalFilename().isEmpty() || files==null || files.toString().length()==0 ){
            System.out.println("文化上传失败!");
            active.setPictures(active1.getPictures());

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
                File fileDir = UploadUtils.getImgDirFile();
                // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
                //  System.out.println(fileDir.getAbsolutePath());

                try {

                    System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                    // 构建真实的文件路径
                    File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                    System.out.println(newFile);
                    // 上传图片到 -》 “绝对路径”
                    files[i].transferTo(newFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();


            active.setPictures(listjson);

        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.US);


        LocalDateTime localDate1 = LocalDateTime.parse(start, formatter);
        LocalDateTime localDate2 = LocalDateTime.parse(end, formatter);

        Timestamp starttime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate1));
        Timestamp endtime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate2));

        if (start ==null || end ==null){
            active.setBegintime(active1.getBegintime());
            active.setEndtime(active1.getEndtime());
        }else if ( starttime.getTime() >= endtime.getTime()){

            model.addAttribute("errMsg","起始时间不能大于结束时间");
            return "admin/active/active-list-detail-update";
        }else {
            active.setBegintime(starttime);
            active.setEndtime(endtime);
        }

        activeRepository.save(active);



        return "redirect:/admin/shetuan/activegl/detail/"+active.getId();
    }

//    活动参加人详情
    @GetMapping("/enjoy/active/{id}")
    public String enjoyactiveget( Model model, @PathVariable("id")int id){

        Active active= activeRepository.findById(id).orElseThrow();

        List<UserinActive> userinActives = userinActiveRepository.findByActiveidOrderByWritetimeDesc(active.getId());

        List<User> users = new ArrayList<>();
        for (var i=0;i<userinActives.size();i++){

            User user = userRepository.findFirstByUsername(userinActives.get(i).getUsername());
            users.add(user);
        }

        model.addAttribute("users",users);
        model.addAttribute("userinActives",userinActives);

        return "shetuan/active/active-enjoy-user";
    }

//    取消人员参加
@GetMapping("/enjoy/delete/{id}")
public String enjoyactivedeleteget( Model model, @PathVariable("id")int id){

   userinActiveRepository.deleteById(id);

    return "redirect:/admin/shetuan/active/sthdgl/list";
}


//反馈通知查询

    @GetMapping("/active/fankui")
    public String activefankuiget(@ModelAttribute("myuser")Shetuan myuser,Model model){

        List<Activefankui> activefankuis = activefankuiRepository.findByStidOrderByWritetimeDesc(myuser.getId());


        model.addAttribute("activefankuis",activefankuis);

        return "shetuan/active/active-activefankui";
    }

    //反馈通知原文
    @GetMapping("/active/fankui/detail/{id}")
    public String activefankuidetailget(@PathVariable("id")int id,Model model){

        Active active = activeRepository.findById(id).orElseThrow();



        model.addAttribute("active",active);

        List<String> pictures = JSONArray.fromObject(active.getPictures());

        model.addAttribute("pictures",pictures);

        return "shetuan/active/active-activefankui-detail";
    }

    //    反馈内容填写
    @GetMapping("/active/fankui/update/{id}")
    public String fankuiupdateget(@PathVariable("id")int id,Model model){

        model.addAttribute("id",id);
        return "shetuan/active/active-activefankui-update";
    }

    @PostMapping("/active/fankui/update/{id}")
    public String fankuiupdatepost(@PathVariable("id")int id,Model model,@RequestParam("liyou")String liyou){


        Activefankui activefankui = activefankuiRepository.findById(id).orElseThrow();

        News news = new News();

        news.setUsername(activefankui.getUsername());
        news.setTopic("反馈处理结果！");
        news.setMain_text("结果为:"+liyou);
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);

        activefankui.setStatus(1);
        activefankuiRepository.save(activefankui);

        return "redirect:/admin/shetuan/active/fankui";
    }



}
