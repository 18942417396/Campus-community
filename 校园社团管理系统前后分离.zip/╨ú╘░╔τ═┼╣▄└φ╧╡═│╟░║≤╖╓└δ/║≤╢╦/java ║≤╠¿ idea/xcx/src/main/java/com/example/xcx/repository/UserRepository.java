package com.example.xcx.repository;


import com.example.xcx.entity.Admin;
import com.example.xcx.entity.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

//存储层
public interface UserRepository extends CrudRepository<User, Integer> {

//  客户端登录
  User findFirstByUsernameAndPassword(String username,String password);

//  客户端注册时是否有一样的用户名
  User findFirstByUsername(String username);


  List<User> findAll();
}
