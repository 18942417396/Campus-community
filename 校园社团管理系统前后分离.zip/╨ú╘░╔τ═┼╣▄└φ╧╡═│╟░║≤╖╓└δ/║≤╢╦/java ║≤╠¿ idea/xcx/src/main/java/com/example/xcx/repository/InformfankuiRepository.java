package com.example.xcx.repository;

import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Informfankui;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface InformfankuiRepository extends CrudRepository<Informfankui, Integer> {

//    后台社团端查询通知反馈
    List<Informfankui> findByStidOrderByWritetimeDesc(int stid);

//    客户端详情页查找反馈
List<Informfankui> findByInformidOrderByWritetimeDesc(int informid );

}
