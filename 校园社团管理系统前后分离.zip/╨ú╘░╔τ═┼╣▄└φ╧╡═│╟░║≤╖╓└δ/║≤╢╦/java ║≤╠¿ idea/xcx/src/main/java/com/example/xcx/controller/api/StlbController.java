package com.example.xcx.controller.api;

import com.example.xcx.entity.Active;
import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.*;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class StlbController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ActiveRepository activeRepository;
    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    InformRepository informRepository;

    @Autowired
    NewsRepository newsRepository;

    //    小程序社团列表获取
    @PostMapping("/stlb/index")
    public JSONArray xcxstlbindexpost(){



        List<Shetuan> shetuans = shetuanRepository.findAllByStatus(1);

        JSONArray array = JSONArray.fromObject(shetuans);


        return array;
    }

    //    小程序社团列表获取搜索
    @PostMapping("/stlb/index/search")
    public JSONArray xcxstlbsearchpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        System.out.println("mysearch"+map.get("shetuanName").toString());

        List<Shetuan> shetuans = shetuanRepository.findByStatusAndShetuanNameLike(1,"%"+map.get("shetuanName").toString()+"%");

        JSONArray array = JSONArray.fromObject(shetuans);


        return array;
    }

    //    小程序社团列表详情页获取通知
    @PostMapping("/stlb/detail")
    public JSONArray xcxstldetailpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);


        List<Inform> informs = informRepository.findByStidAndStatusOrderByWritetimeDesc(Integer.parseInt(map.get("id").toString()),0);

        JSONArray array = JSONArray.fromObject(informs);


        return array;
    }

    //    小程序社团列表详情页获取社团信息
    @PostMapping("/stlb/detail/getshetuan")
    public JSON xcxstldetailgetshetuanpost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        Shetuan shetuan = shetuanRepository.findById(Integer.parseInt(map.get("id").toString())).orElseThrow();

        JSON json = JSONObject.fromObject(shetuan);

        return json;
    }

    // 社团列表寻找通知
    @PostMapping("/stlb/detail/getshetuan/active")
    public JSONArray xcxstldetailgetshetuanactivepost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        List<Active> actives = activeRepository.findByStidAndStatusOrderByWritetime(Integer.parseInt(map.get("id").toString()),1);

        JSONArray jsonArray = JSONArray.fromObject(actives);

        return jsonArray;
    }

    @PostMapping("/active/detail")
    public JSON xcxactivedetailgetshetuanactivepost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);

        Active active = activeRepository.findById(Integer.parseInt(map.get("id").toString())).orElseThrow();

        JSON json = JSONObject.fromObject(active);


        return json;
    }


}
