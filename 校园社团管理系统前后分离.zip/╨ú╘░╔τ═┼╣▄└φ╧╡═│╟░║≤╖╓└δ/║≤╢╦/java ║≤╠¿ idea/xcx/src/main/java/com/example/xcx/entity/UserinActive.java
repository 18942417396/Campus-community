package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

//用户活动申请表
@Entity
@Data
public class UserinActive {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int activeid;
    private  String username;
    private Timestamp writetime;


    public UserinActive(){
        //         每次post请求构造的时候会创建当前时间
        this.writetime = new Timestamp(System.currentTimeMillis());
    }
}
