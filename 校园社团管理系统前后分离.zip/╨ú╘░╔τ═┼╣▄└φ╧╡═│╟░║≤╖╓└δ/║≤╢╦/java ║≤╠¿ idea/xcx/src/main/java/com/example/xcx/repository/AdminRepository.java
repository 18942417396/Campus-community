package com.example.xcx.repository;


import com.example.xcx.entity.Admin;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AdminRepository extends CrudRepository<Admin, Integer> {

//    登录
    Admin findFirstByAdminNameAndPassword(String adminName, String password);
//    注册
    Admin findFirstByAdminName(String adminName);


}
