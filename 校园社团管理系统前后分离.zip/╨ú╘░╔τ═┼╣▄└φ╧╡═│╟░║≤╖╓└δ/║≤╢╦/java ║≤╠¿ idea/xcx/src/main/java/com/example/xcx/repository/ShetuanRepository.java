package com.example.xcx.repository;

import com.example.xcx.entity.Admin;
import com.example.xcx.entity.Shetuan;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ShetuanRepository extends CrudRepository<Shetuan, Integer> {

//    登录
    Shetuan findFirstByShetuanNameAndPasswordAndStatus(String shetuanName, String password,int status);

//    前端注册
    Shetuan findFirstByShetuanName(String shetuanName);

//   后端注册申请审核

    List<Shetuan> findAllByStatus(int status);

//    后端社团管理

    List<Shetuan> findAll();

//    小程序客户端社团列表搜索
    List<Shetuan> findByStatusAndShetuanNameLike(int status,String ShetuanName);

}
