package com.example.xcx.controller.shetuanController;

import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.ShetuanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/shetuan")
public class SLoginController {

    @Autowired
    ShetuanRepository shetuanRepository;

//    后台登录

    @GetMapping("/login")
    public String loginadminGet(@ModelAttribute("shetuan") Shetuan shetuan, Model model){


//        返回视图名称
        return "/shetuan/Slogin";
    }


    //    login中提交表单
    @PostMapping("/login")
    public String loginadminPost(@ModelAttribute("shetuan")Shetuan shetuan, Model model){

        if (shetuan.getShetuanName().length() == 0 || shetuan.getPassword().length() == 0 || shetuan.getShetuanName().trim() == "" || shetuan.getPassword().trim() == ""){
            model.addAttribute("errMsg","账号或密码错误");
            return "/shetuan/Slogin";
        }

        Shetuan loginadmin = shetuanRepository.findFirstByShetuanNameAndPasswordAndStatus(shetuan.getShetuanName(),shetuan.getPassword(),1);



        if (loginadmin != null){
//           存缓存，放session
            model.addAttribute("myuser",loginadmin);
            String logintype = new String();
            logintype = "社团";
            model.addAttribute("logintype",logintype);
            System.out.println("login success");
            return "redirect:/admin/shetuan/home";
        }else {
            model.addAttribute("errMsg","账号或密码错误");
            return "/shetuan/Slogin";
        }


    }


    //    后台注册

    @GetMapping("/register")
    public String registeradminGet(@ModelAttribute("shetuan") Shetuan shetuan){

   //        返回视图名称
        return "/shetuan/Sregister";
    }

    //    login中提交表单
    @PostMapping("/register")
    public String registeradminPost(@ModelAttribute("shetuan")Shetuan shetuan, Model model){

        if (shetuan.getShetuanName().length() == 0 || shetuan.getPassword().length() == 0 || shetuan.getShetuanName().trim() == "" || shetuan.getPassword().trim() == ""){
            model.addAttribute("errMsg","账号或密码错误");
            return "/shetuan/Sregister";
        }

        Shetuan loginadmin = shetuanRepository.findFirstByShetuanName(shetuan.getShetuanName());

        if (loginadmin != null){
            model.addAttribute("errMsg","账号重复!");
            return "/shetuan/Sregister";


        }else {

            Shetuan shetuan1 = new Shetuan();
            shetuan1.setShetuanName(shetuan.getShetuanName());
            shetuan1.setPassword(shetuan.getPassword());
            shetuan1.setStatus(1);
            shetuanRepository.save(shetuan1);
            System.out.println("register success");
            return "redirect:/admin/shetuan/login";

        }


    }




}
