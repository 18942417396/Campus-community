package com.example.xcx.repository;

import com.example.xcx.entity.Inform;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface InformRepository extends CrudRepository<Inform, Integer> {


//    社团通知管理
    List<Inform> findByStidAndStatusOrderByWritetimeDesc(int stid,int status);

//    系统管理员通知管理
List<Inform> findByOrderByWritetimeDesc();
//    小程序首页通知展示

    List<Inform> findByStatusOrderByWritetimeDesc(int status);

    //    小程序社团通知页面查询搜索

    List<Inform> findByStatusAndTopicLikeAndTypeOrderByWritetimeDesc(int status,String topic,String type);
}
