package com.example.xcx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.support.SessionStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class IndexController {
    @GetMapping("/index")
    public String index(Model model){
        System.out.println("i can comming");

        return "index";
    }

    @GetMapping("/out")
    public String out(HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus){
        System.out.println("i go out");


        Object admin =request.getSession().getAttribute("myuser");
        String logintype = (String) request.getSession().getAttribute("logintype");
        System.out.println("kan admin:"+admin);
        System.out.println("kan logintype"+logintype);
        request.getSession().removeAttribute("myuser");
        request.getSession().removeAttribute("logintype");
        Object admin1 =request.getSession().getAttribute("myuser");
        String logintype1 = (String) request.getSession().getAttribute("logintype");
        System.out.println("kan admin1:"+admin1);
        System.out.println("kan logintype1"+logintype1);
        return "redirect:/index";
    }
}
