package com.example.xcx.controller.api;

import com.example.xcx.controller.shetuanController.STimelineController;
import com.example.xcx.entity.Apply;
import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.*;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.criteria.CriteriaBuilder;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class StzxController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    InformRepository informRepository;

    @Autowired
    NewsRepository newsRepository;

    @Autowired
    ApplyRepository applyRepository;

    @PostMapping("/stzx/uploadimg/apply")
    public String stzxuploadimgapplypost(@RequestParam(value = "file",required = false)MultipartFile file){

        System.out.println("进来了上传图片接口");
        System.out.println(file);
        String msg = "";
        if (file.isEmpty()) {
            System.out.println("文化上传失败!");
            return "request fail";
        }else {
            System.out.println("文化上传成功!");
            // 拿到文件名
            String filename = file.getOriginalFilename();
            System.out.println("0"+filename);//获取图片的文件名
            // 存放上传图片的文件夹
            File fileDir = UserController.UploadUtils.getImgDirFile();
            // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
            //  System.out.println(fileDir.getAbsolutePath());

            try {
                System.out.println(fileDir.getAbsolutePath());
                System.out.println(File.separator);
                System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                // 构建真实的文件路径
                File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                System.out.println(newFile);
                // 上传图片到 -》 “绝对路径”
                file.transferTo(newFile);
                msg = "上传成功!";

                return "http://localhost:8080/static/face_img/"+filename;
            } catch (IOException  e) {
                e.printStackTrace();
            }



        }

        return "request fail";
    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }

    //    小程序社团列表详情页获取通知
    @PostMapping("/stzx/apply")
    public String xcxstzxapplypost(@RequestBody String jsonString){


        Map map = JSONObject.fromObject(jsonString);
        System.out.println(map);

        String pictures = map.get("pictures").toString();
        System.out.println(pictures);

        Apply apply = new Apply();

        apply.setUsername(map.get("username").toString());
        apply.setName(map.get("name").toString());
        apply.setStid(Integer.parseInt(map.get("stid").toString()));
        apply.setSex(map.get("sex").toString());
        apply.setMianmao(map.get("mianmao").toString());
        apply.setJob(map.get("job").toString());
        apply.setIntroduce(map.get("introduce").toString());
        apply.setPictures(pictures);
        apply.setStatus(0);

        applyRepository.save(apply);



        return "ok";
    }

}
