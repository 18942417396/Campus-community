package com.example.xcx.controller.adminController;


import com.example.xcx.entity.Active;
import com.example.xcx.entity.Apply;
import com.example.xcx.entity.News;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.ActiveRepository;
import com.example.xcx.repository.ApplyRepository;
import com.example.xcx.repository.NewsRepository;
import com.example.xcx.repository.ShetuanRepository;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/admin")
public class ATimelineController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    ApplyRepository applyRepository;
    @Autowired
    NewsRepository newsRepository;
    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    ActiveRepository activeRepository;

    @GetMapping("/home")
    public String homeget(){

        Object admin =request.getSession().getAttribute("myuser");
        String logintype = (String) request.getSession().getAttribute("logintype");
        System.out.println("admin:is"+admin);
        System.out.println("logintype:is"+logintype);
        return "admin/Aindex";
    }

    @GetMapping("/welcome")
    public String welcomeget(){

        return "welcome";
    }
//社团注册表显示
    @GetMapping("/stzcsq")
    public String stzcsqget(Model model){

        List<Shetuan> shetuans = shetuanRepository.findAllByStatus(0);

        model.addAttribute("shetuans",shetuans);

        return "admin/shzx/shzx-stzcsq";
    }
//    同意社团申请
    @GetMapping("/stzcsq/update/{id}")
    public String stzcsqupdateget(Model model,@PathVariable("id")int id){

        System.out.println("i come stzcsq update");

        Shetuan shetuan = shetuanRepository.findById(id).orElseThrow();

        shetuan.setStatus(1);

        shetuanRepository.save(shetuan);

        News news = new News();

        news.setUsername(shetuan.getCreateusername());
        news.setTopic("您申请注册的社团已同意！");
        news.setMain_text("~请在社团管理后台登录并管理;"+"账号："+shetuan.getShetuanName()+"密码："+shetuan.getPassword());
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);


        return "redirect:/admin/admin/stzcsq";
    }

//    拒绝社团申请
@GetMapping("/stzcsq/jujue/{id}")
public String stzcsqjujueget(@PathVariable("id")int id,Model model){

        model.addAttribute("id",id);
    return "admin/shzx/shzx-stzcsq-jujue";
}

    @PostMapping("/stzcsq/jujue/{id}")
    public String stzcsqjujuepost(@PathVariable("id")int id,Model model,@RequestParam("liyou")String liyou){

        Shetuan shetuan = shetuanRepository.findById(id).orElseThrow();



        News news = new News();

        news.setUsername(shetuan.getCreateusername());
        news.setTopic("您申请注册的社团被拒绝！");
        news.setMain_text("理由为:"+liyou);
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);

        shetuan.setStatus(2);
        shetuanRepository.save(shetuan);

        return "redirect:/admin/admin/stzcsq";
    }

//社团活动审核列表
@GetMapping("/sthdsq/list")
public String sthdsqlistget(Model model){

        List<Active> actives = activeRepository.findByStatusOrderByWritetime(0);

        model.addAttribute("actives",actives);
    return "admin/shzx/shzx-sthdsq";
}

//社团活动详情

    @GetMapping("/active/detail/{id}")
    public String activedetailget(@PathVariable("id")int id, Model model){

        Active active = activeRepository.findById(id).orElseThrow();

        Shetuan shetuan = shetuanRepository.findById(active.getStid()).orElseThrow();


        List<String> pictures = JSONArray.fromObject(active.getPictures());
        model.addAttribute("shetuan",shetuan);
        model.addAttribute("active",active);
        model.addAttribute("pictures",pictures);
        return "admin/shzx/shzx-sthdsq-detail";
    }

//    同意活动
@GetMapping("/active/detail/true/{id}")
public String activedetailtrueget(@PathVariable("id")int id, Model model){

        Active active = activeRepository.findById(id).orElseThrow();
        active.setStatus(0);
        activeRepository.save(active);

        Shetuan shetuan = shetuanRepository.findById(active.getStid()).orElseThrow();


    News news = new News();

    news.setUsername(shetuan.getCreateusername());
    news.setTopic("活动申请通知！");
    news.setMain_text("您社团申请的活动已被通过！~");
    news.setFromusername("系统");
    news.setStatus(0);

    newsRepository.save(news);

    return "redirect:/admin/admin/sthdsq/list";
}

    //    拒绝活动申请
    @GetMapping("/active/detail/false/{id}")
    public String stzcsqfalseget(@PathVariable("id")int id,Model model){

        model.addAttribute("id",id);
        return "admin/shzx/shzx-sthdsq-detail-false";
    }

    @PostMapping("/active/detail/false/{id}")
    public String stzcsqfalsepost(@PathVariable("id")int id,Model model,@RequestParam("liyou")String liyou){


        Active active = activeRepository.findById(id).orElseThrow();

        active.setStatus(2);

        activeRepository.save(active);

        Shetuan shetuan = shetuanRepository.findById(active.getStid()).orElseThrow();

        News news = new News();

        news.setUsername(shetuan.getCreateusername());
        news.setTopic("活动拒绝通知！");
        news.setMain_text("您社团申请的活动被拒绝！理由是"+liyou);
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);


        return "redirect:/admin/admin/sthdsq/list";
    }


}
