package com.example.xcx.repository;

import com.example.xcx.entity.Active;
import com.example.xcx.entity.Apply;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ActiveRepository extends CrudRepository<Active, Integer> {
    //    后台系统管理，活动申请审核列表
    List<Active> findByStatusOrderByWritetime(int status);

//    后台系统管理，后台活动列表
List<Active> findByOrderByWritetime();

// 后台社团管理，活动列表
    List<Active> findByStidOrderByWritetime(int stid);

//    小程序端在社团页面查找活动
List<Active> findByStidAndStatusOrderByWritetime(int stid,int status);
}
