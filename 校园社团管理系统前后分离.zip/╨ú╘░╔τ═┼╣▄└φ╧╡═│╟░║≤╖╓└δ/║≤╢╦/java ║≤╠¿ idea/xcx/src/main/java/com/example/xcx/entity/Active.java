package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

//社团活动
@Entity
@Data
public class Active {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
//    活动内容
    private String topic;
    private String main_text;
    private String type;
    private String pictures;
//    地点
    private String position;
    private Timestamp begintime;
    private Timestamp endtime;

//    实时的报名人数
    private int number;
    private Timestamp writetime;
    private int stid;
    private int status;
//0未处理，1已通过，2已拒绝

    public Active(){
        //         每次post请求构造的时候会创建当前时间
        this.writetime = new Timestamp(System.currentTimeMillis());
    }
}
