package com.example.xcx.controller.adminController;

import com.example.xcx.entity.Admin;
import com.example.xcx.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/admin")
public class ALoginController {

    @Autowired
    AdminRepository adminRepository;

//    后台登录

    @GetMapping("/login")
    public String loginadminGet(@ModelAttribute("admin") Admin admin, Model model){


//        返回视图名称
        return "/admin/Alogin";
    }


    //    login中提交表单
    @PostMapping("/login")
    public String loginadminPost(@ModelAttribute("admin")Admin admin, Model model){

        if (admin.getAdminName().length() == 0 || admin.getPassword().length() == 0 || admin.getAdminName().trim() == "" || admin.getPassword().trim() == ""){
            model.addAttribute("errMsg","账号或密码错误");
            return "/admin/Alogin";
        }

        Admin loginadmin = adminRepository.findFirstByAdminNameAndPassword(admin.getAdminName(),admin.getPassword());



        if (loginadmin != null){
//           存缓存，放session
            model.addAttribute("myuser",loginadmin);
            String logintype = new String();
            logintype = "后台";
            model.addAttribute("logintype",logintype);
            System.out.println("login success");
            return "redirect:/admin/admin/home";
        }else {
            model.addAttribute("errMsg","账号或密码错误");
            return "/admin/Alogin";
        }


    }


    //    后台注册

    @GetMapping("/register")
    public String registeradminGet(@ModelAttribute("admin") Admin admin){

   //        返回视图名称
        return "/admin/Aregister";
    }

    //    login中提交表单
    @PostMapping("/register")
    public String registeradminPost(@ModelAttribute("admin")Admin admin, Model model){

        if (admin.getAdminName().length() == 0 || admin.getPassword().length() == 0 || admin.getAdminName().trim() == "" || admin.getPassword().trim() == ""){
            model.addAttribute("errMsg","账号或密码错误");
            return "/admin/Aregister";
        }

        Admin loginadmin = adminRepository.findFirstByAdminName(admin.getAdminName());

        if (loginadmin != null){
            model.addAttribute("errMsg","账号重复!");
            return "/admin/Aregister";


        }else {

            Admin admin1 = new Admin();
            admin1.setAdminName(admin.getAdminName());
            admin1.setPassword(admin.getPassword());
            admin1.setStatus(0);
            admin1.setJob("common");
            adminRepository.save(admin1);
            System.out.println("register success");
            return "redirect:/admin/admin/login";

        }


    }




}
