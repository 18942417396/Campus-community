package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

//社团内部消息
@Entity
@Data
public class STINInform {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String topic;
    private String main_text;
    private String type;
    private String pictures;
    private Timestamp writetime;
    private int stid;
    private int status;
//    0正常状态，1已下架

    public STINInform(){
        //         每次post请求构造的时候会创建当前时间
        this.writetime = new Timestamp(System.currentTimeMillis());
    }
}
