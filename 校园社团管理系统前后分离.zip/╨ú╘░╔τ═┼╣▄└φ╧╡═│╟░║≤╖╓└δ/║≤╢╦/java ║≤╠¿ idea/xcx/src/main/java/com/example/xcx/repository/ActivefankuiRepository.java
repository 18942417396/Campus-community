package com.example.xcx.repository;

import com.example.xcx.entity.Activefankui;
import com.example.xcx.entity.Informfankui;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ActivefankuiRepository extends CrudRepository<Activefankui, Integer> {

    //    后台社团端查询活动反馈
    List<Activefankui> findByStidOrderByWritetimeDesc(int stid);

//    客户端详情页查找反馈
List<Activefankui> findByActiveidOrderByWritetimeDesc(int Activeid);


}
