package com.example.xcx.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
public class Informfankui {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int informid;
    private int stid;
    private String main_text;
    private String username;
    private Timestamp writetime;

    private int status;
//    0未处理，1已处理

    public Informfankui(){
        //         每次post请求构造的时候会创建当前时间
        this.writetime = new Timestamp(System.currentTimeMillis());
    }
}
