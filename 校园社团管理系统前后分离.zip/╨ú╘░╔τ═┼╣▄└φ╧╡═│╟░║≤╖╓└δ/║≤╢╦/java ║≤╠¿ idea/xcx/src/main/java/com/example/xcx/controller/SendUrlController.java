package com.example.xcx.controller;


import net.sf.json.JSON;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

//登录获取openid和会话秘钥
@RestController
@RequestMapping("/WEIXINlogin")
public class SendUrlController {
    @Autowired
    RestTemplate restTemplate;

    @RequestMapping(value = "/openid", method = RequestMethod.GET)
    @ResponseBody
    public String getOpenId(@RequestParam("code") String code, HttpServletRequest request) {
        //获取session
        HttpSession session = request.getSession();

        String forObject = restTemplate.getForObject("https://api.weixin.qq.com/sns/jscode2session?appid=wx0b0e582ad986bee6&secret=60571469cbfda36c77f76ca09be7e74a&js_code=" + code + "&grant_type=authorization_code", String.class);
        try {
            System.out.println(forObject);

//            // 当code已经使用过，则不能查出openid
//            String openid = "code错误";
//            if (map.containsKey("openid")) {
//                openid = map.get("openid").toString();
//            }
            // 将json转为map
            Map map = JSONObject.fromObject(forObject);
            System.out.println("map:"+map);
            System.out.println("map,openid:"+map.get("openid"));
            session.setAttribute("_openid",map.get("openid"));
            String _openid = (String) request.getSession().getAttribute("_openid");
            System.out.println("session include _openid"+_openid);
            System.out.println(request.getSession().getId());
            return forObject;
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
}
