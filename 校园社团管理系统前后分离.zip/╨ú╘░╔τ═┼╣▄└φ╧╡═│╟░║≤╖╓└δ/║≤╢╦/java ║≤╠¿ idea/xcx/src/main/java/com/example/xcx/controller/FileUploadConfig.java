package com.example.xcx.controller;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class FileUploadConfig implements WebMvcConfigurer {


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/face_img/**").addResourceLocations("file:C:\\Users\\NHP\\Desktop\\闲鱼社团管理系统前后分离\\后端\\java 后台 idea\\xcx\\src\\main\\resources\\static\\face_img\\");
    }
}
