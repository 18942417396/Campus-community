package com.example.xcx.repository;

import com.example.xcx.entity.Active;
import com.example.xcx.entity.UserinActive;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserinActiveRepository extends CrudRepository<UserinActive, Integer> {

    List<UserinActive> findByActiveidOrderByWritetimeDesc(int activeid);

//    客户端查找报名是否存在
    UserinActive findFirstByActiveidAndUsername(int activeid,String username);

//    客户端我的页面查找今日活动
List<UserinActive> findByUsernameOrderByWritetimeDesc(String username);

}
