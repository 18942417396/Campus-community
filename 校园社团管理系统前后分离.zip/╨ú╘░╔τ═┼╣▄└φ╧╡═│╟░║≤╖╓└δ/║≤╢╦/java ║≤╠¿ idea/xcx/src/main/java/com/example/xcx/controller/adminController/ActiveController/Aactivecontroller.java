package com.example.xcx.controller.adminController.ActiveController;

import com.example.xcx.controller.shetuanController.STimelineController;
import com.example.xcx.entity.Active;
import com.example.xcx.entity.Inform;
import com.example.xcx.entity.Shetuan;
import com.example.xcx.repository.ActiveRepository;
import com.example.xcx.repository.ApplyRepository;
import com.example.xcx.repository.NewsRepository;
import com.example.xcx.repository.ShetuanRepository;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Controller
@SessionAttributes({"myuser","logintype"})
@RequestMapping("/admin/admin")
public class Aactivecontroller {

    @Autowired
    HttpServletRequest request;

    @Autowired
    ApplyRepository applyRepository;
    @Autowired
    NewsRepository newsRepository;
    @Autowired
    ShetuanRepository shetuanRepository;

    @Autowired
    ActiveRepository activeRepository;

    //社团活动管理列表
    @GetMapping("/sthdgl/list")
    public String sthdgllistget(Model model){

        List<Active> actives = activeRepository.findByOrderByWritetime();

        model.addAttribute("actives",actives);
        return "admin/active/active-list";
    }
//社团活动详情

    @GetMapping("/activegl/detail/{id}")
    public String activedetailglget(@PathVariable("id")int id, Model model){

        Active active = activeRepository.findById(id).orElseThrow();

        Shetuan shetuan = shetuanRepository.findById(active.getStid()).orElseThrow();


        List<String> pictures = JSONArray.fromObject(active.getPictures());
        model.addAttribute("shetuan",shetuan);
        model.addAttribute("active",active);
        model.addAttribute("pictures",pictures);
        return "admin/active/active-list-detail";
    }


    @GetMapping("/change/active/{id}")
    public String sthdgllistget(@ModelAttribute("Active")Active active, Model model, @PathVariable("id")int id){

        Active active1= activeRepository.findById(id).orElseThrow();

        JSONArray jsonArray = JSONArray.fromObject(active1.getPictures());

       model.addAttribute("jsonArray",jsonArray);
        model.addAttribute("active",active1);
        model.addAttribute("thispictures",active1.getPictures());

        return "admin/active/active-list-detail-update";
    }

    @PostMapping("/change/active/{id}")
    public String sthdgllistpost(@RequestParam(value = "picturefile",required = false) MultipartFile[] files, @ModelAttribute("Active")Active active, Model model, @PathVariable("id")int id,@RequestParam("start")String start ,@RequestParam("end")String end){

        Active active1 = activeRepository.findById(id).orElseThrow();

        ArrayList<String> stringArrayList = new ArrayList<>();
        String  listjson = "";

        if (files.length==0 || files[0].getOriginalFilename().isEmpty() || files==null || files.toString().length()==0 ){
            System.out.println("文化上传失败!");
            active.setPictures(active1.getPictures());

        }else {

            for (var i = 0;i<= files.length-1;i++){


                String filename = files[i].getOriginalFilename();
                stringArrayList.add("http://localhost:8080/static/face_img/"+filename);
                // 存放上传图片的文件夹
                File fileDir = UploadUtils.getImgDirFile();
                // 输出文件夹绝对路径  -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径
                //  System.out.println(fileDir.getAbsolutePath());

                try {

                    System.out.println(fileDir.getAbsolutePath() + File.separator + filename);
                    // 构建真实的文件路径
                    File newFile = new File(fileDir.getAbsolutePath() + File.separator + filename);
                    System.out.println(newFile);
                    // 上传图片到 -》 “绝对路径”
                    files[i].transferTo(newFile);

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            System.out.println("i get" +stringArrayList);
            JSONArray pictures = JSONArray.fromObject(stringArrayList);
            listjson = pictures.toString();


            active.setPictures(listjson);

        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.US);


        LocalDateTime localDate1 = LocalDateTime.parse(start, formatter);
        LocalDateTime localDate2 = LocalDateTime.parse(end, formatter);

        Timestamp starttime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate1));
        Timestamp endtime = Timestamp.valueOf(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate2));

        if (start ==null || end ==null){
            active.setBegintime(active1.getBegintime());
            active.setEndtime(active1.getEndtime());
        }else if ( starttime.getTime() >= endtime.getTime()){

            model.addAttribute("errMsg","起始时间不能大于结束时间");
            return "admin/active/active-list-detail-update";
        }else {
            active.setBegintime(starttime);
            active.setEndtime(endtime);
        }

        activeRepository.save(active);



        return "redirect:/admin/admin/activegl/detail/"+active.getId();
    }

    static class UploadUtils{
        // 项目根路径下的目录  -- SpringBoot static 目录相当于是根路径下（SpringBoot 默认）
        public final static String IMG_PATH_PREFIX = "static/face_img";

        public static File getImgDirFile(){

            // 构建上传文件的存放 "文件夹" 路径
            String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);
            File fileDir = new File(fileDirPath);
            if(!fileDir.exists()){
                // 递归生成文件夹
                fileDir.mkdirs();
            }
            return fileDir;
        }
    }
}
