package com.example.xcx.controller.shetuanController;


import com.example.xcx.entity.*;
import com.example.xcx.repository.*;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@SessionAttributes("myuser")
@RequestMapping("/admin/shetuan")
public class SstzxController {

    @Autowired
    InformRepository informRepository;

    @Autowired
    InformfankuiRepository informfankuiRepository;

    @Autowired
    NewsRepository newsRepository;

    @Autowired
    ApplyRepository applyRepository;

    @Autowired
    STUSRepository stusRepository;


//   招新申请列表
    @GetMapping("/stzx/list")
    public String stzxlistget(Model model,@ModelAttribute("myuser")Shetuan shetuan){

        List<Apply> applies = applyRepository.findByStatusAndStidOrderByWritetime(0,shetuan.getId());

        model.addAttribute("applies",applies);


        return "shetuan/zxgl/zxgl-zxsq";
    }

//    招新申请详情
@GetMapping("/stzx/list/detail/{id}")
public String stzxlistdetailget(Model model,@ModelAttribute("myuser")Shetuan shetuan,@PathVariable("id")int id){

    Apply apply = applyRepository.findById(id).orElseThrow();

    List<String> pictures = JSONArray.fromObject(apply.getPictures());

    model.addAttribute("apply",apply);
    model.addAttribute("pictures",pictures);


    return "shetuan/zxgl/zxgl-zxsq-detail";
}

//同意申请
@GetMapping("/stzx/list/detail/true/{id}")
public String stzxlistdetailtrueget(Model model,@ModelAttribute("myuser")Shetuan shetuan,@PathVariable("id")int id){

    Apply apply = applyRepository.findById(id).orElseThrow();

    apply.setStatus(1);
    applyRepository.save(apply);

    STUS stus = new STUS();

    stus.setUsername(apply.getUsername());
    stus.setStid(apply.getStid());
    stus.setFromapplyid(apply.getId());
    stus.setStatus(0);
    stusRepository.save(stus);

    News news = new News();

    news.setUsername(apply.getUsername());
    news.setTopic("社团同意申请通知！");
    news.setMain_text("您提交的社团加入申请已通过，可在对应社团信息里查看内部信息！~");
    news.setFromusername("系统");
    news.setStatus(0);

    newsRepository.save(news);



    return "redirect:/admin/shetuan/stzx/list";
}

    //拒绝申请
    @GetMapping("/stzx/list/detail/false/{id}")
    public String stzxlistdetailfalseget(Model model,@ModelAttribute("myuser")Shetuan shetuan,@PathVariable("id")int id){

        model.addAttribute("id",id);

        return "shetuan/zxgl/zxgl-zxsq-detail-false";
    }

    @PostMapping("/stzx/list/detail/false/{id}")
    public String stzxlistdetailfalsepost(Model model,@ModelAttribute("myuser")Shetuan shetuan,@PathVariable("id")int id,@RequestParam("liyou")String liyou){

        Apply apply = applyRepository.findById(id).orElseThrow();

        apply.setStatus(1);
        applyRepository.save(apply);



        News news = new News();

        news.setUsername(apply.getUsername());
        news.setTopic("社团拒绝申请通知！");
        news.setMain_text("您提交的社团申请未被通过！~理由："+liyou);
        news.setFromusername("系统");
        news.setStatus(0);

        newsRepository.save(news);


        return "redirect:/admin/shetuan/stzx/list";
    }

}
