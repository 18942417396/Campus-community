// app.js
App({
  onLaunch() {

    var that = this
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    if(wx.getStorageSync('userInfo')){
      this.globalData.userInfo = wx.getStorageSync('userInfo')
    }

   // 登录
   wx.login({
    success: res => {
      // 发送 res.code 到后台换取 openId, sessionKey, unionId
     console.log(res);
      if (res.code) {
        //发起网络请求
        wx.request({
          url: 'http://localhost:8080/WEIXINlogin/openid',
          data: {
            code: res.code
          },
          success (res) {
            console.log(res)
            wx.setStorageSync('openid', res.data.openid),
            wx.setStorageSync('cookieKey', res.header["Set-Cookie"])
            that.globalData.openid = wx.getStorageSync('openid')
          },
          fail(err){
            wx.showToast({
              title: '服务器出错了！'+err.errMsg,
              icon:'error',
              duration:5000,
            })
          }
        })
      } else {
        console.log('登录失败！' + res.errMsg)
      }
    }
  })

    
 



        // 获取手机系统信息
    wx.getSystemInfo({
      success: res => {
        //导航高度
        this.globalData.navHeight = res.statusBarHeight + 46;
      }, fail(err) {
        console.log(err);
      }
    })

    const { statusBarHeight, platform } = wx.getSystemInfoSync()
    const { top, height } = wx.getMenuButtonBoundingClientRect()

    // 状态栏高度
    wx.setStorageSync('statusBarHeight', statusBarHeight)
    // 胶囊按钮高度 一般是32 如果获取不到就使用32
    wx.setStorageSync('menuButtonHeight', height ? height : 32)
    
    // 判断胶囊按钮信息是否成功获取
    if (top && top !== 0 && height && height !== 0) {
        const navigationBarHeight = (top - statusBarHeight) * 2 + height
  // 导航栏高度
        wx.setStorageSync('navigationBarHeight', navigationBarHeight)
    } else {
        wx.setStorageSync(
          'navigationBarHeight',
          platform === 'android' ? 48 : 40
        )
    }

  },
  globalData: {
    userInfo: null,
    openid:null,
    navHeight: 0,
    tomacat:'http://localhost:8080',
    loading:'https://756e-uniplannet-7gloqwk1349eae41-1315016759.tcb.qcloud.la/2023-2-8-secondhand500/loading.gif?sign=de9f1b8b60de61bb8bea0bbb9c23e1c7&t=1677121598'
  }
})
