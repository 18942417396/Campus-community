export interface Day {
    date: Date;
    type: string;
    text: number;
    bottomInfo?: string;
}
