const util = require("../../utils/src");
const app = getApp()

Page({
  data: {
    // tomacat:app.globalData.tomacat +'/static/face_img/',
    
    loadingsrc:app.globalData.loading
  },
  
  goregister(){
   wx.navigateTo({
     url: '/pages/register/register',
   })
  },

  // 表单提交
   formSubmit(e) {
    var that = this
    wx.showLoading({
      title: '登录中',
    })
   
    
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if(e.detail.value.username =="" || e.detail.value.username.length == 0 || e.detail.value.password =="" || e.detail.value.password.length == 0 ){

      wx.showToast({
        title: '格式错误！',
        icon:'none'
      })
    }else{



      console.log("提交表单成功！");

   

      wx.request({
        url: util.tomacat + "/user/login", 
        data: {
          username: e.detail.value.username,
          password:e.detail.value.password,
        },
        method:'POST',
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        success (res) {
          console.log(res.data)
          if (res.data == "fail") {
            wx.showToast({
              title: '登录失败！',
              icon:'error'
            })
            
          }else{

            wx.setStorageSync('userInfo', res.data)
            app.globalData.userInfo = wx.getStorageSync('userInfo')
            wx.hideLoading({
              success: (res) => {
                wx.showToast({
                  title: '登录成功！',
                  icon:'success',
                  duration:500
                })
                setTimeout(function(){
                  wx.navigateBack({
                    delta: 1,
                  })
                },500)
               
              },
            })
          }
         
        },
        fail(err){
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        }
      })

    }
   

      

    
  },

 
 


 


})