
// pages/grxx/grxx.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // tomacat:app.globalData.tomacat + '/static/face_img/'
  },
  formSubmit(e){
    console.log(e);

    wx.showLoading({
      title: '保存',
    })
   
    var that = this
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if(e.detail.value.username =="" || e.detail.value.username.length == 0){

      wx.showToast({
        title: '格式错误！',
        icon:'none'
      })
    }else{

      console.log("提交表单成功！");
     
      
      wx.request({
        url: app.globalData.tomacat + "/user/update", 
        data: {
          username: e.detail.value.username,
          faceimg: that.data.tempImgList
        },
        method:'POST',
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        success (res) {
          console.log(res.data)
          wx.setStorageSync('userInfo', res.data)
          app.globalData.userInfo = wx.getStorageSync('userInfo')
          wx.hideLoading({
            success: (res) => {
              wx.showToast({
                title: '保存成功！',
                icon:'success'
              })
             
            },
          })
        },
        fail(err){
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        }
      })

    }
   

   
  },

  chooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album','camera'],
      success(res){
        console.log(res)
        console.log(res.tempFilePaths)
          that.setData({
            tempImgList:res.tempFilePaths[0]
          })
           //上传图片
      that.uploadImage()

          
         
      }
    })
  },

  uploadImage(){
    var that = this
   
    wx.uploadFile({
      url: app.globalData.tomacat+ "/user/faceimg/upload",
      name:"file",
      filePath: that.data.tempImgList, // 小程序临时文件路径
      header: {
        "content-type": "multipart/form-data"
      },
      success: res => {
        // 返回文件 ID
        console.log("上传中",res)
         that.setData({
          tempImgList:res.data
         })
         

         console.log("我的新头像"+that.data.tempImgList);

      },
      fail:err =>{
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        
      }
      
    })
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.setData({
      tempImgList:app.globalData.userInfo.faceimg,
      username:app.globalData.userInfo.username
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})