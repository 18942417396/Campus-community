// pages/myactive/myactive.js
const app = getApp()
const util = require("../../utils/src");
const util2 = require("../../utils/util")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingsrc:app.globalData.loading,
    dataList:[],
    loading:true,
  },
  goitem(e){
    wx.navigateTo({
      url: '/pages/stlb/detail/detail?id='+e.currentTarget.dataset.id,
    })
   },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getData()
  },
  getData(){
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/st/mine/all', //仅为示例，并非真实的接口地址
      data:{
      username:app.globalData.userInfo.username
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data


        that.setData({
          dataList:dataList,
          loading:false
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
  },

  onPullDownRefresh(){

    var that = this
    this.setData({
      dataList:[],
      loading:true
    })

    setTimeout(function(){

      that.getData()
    },1000)

  },


})