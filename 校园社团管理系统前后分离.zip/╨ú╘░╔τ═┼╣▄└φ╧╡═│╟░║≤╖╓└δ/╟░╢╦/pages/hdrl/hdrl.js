// pages/calendar/calendar.js
const app =getApp()
const util = require("../../utils/util2");
const util2 = require("../../utils/util")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    dataList:[],
    loading:true,
    loadingsrc:app.globalData.loading,
    date: util.selectdate(new Date),
    time :'00:00'
  },
  goactive(e){
    wx.navigateTo({
      url: '/pages/active/active?id='+e.currentTarget.dataset.id,
    })
  },
  bindselect(e){
    var that = this
    console.log(e);
    that.setData({
      dataList:[],
      loading:true
    })
    var time = e.detail.getTime();
    console.log(time);
    var end = ((time /1000)+24*60*60)*1000
     
    setTimeout(function(){
      that.changeData(time,end)
    },1000)
   
  },

  changeData(a,b){

    var that = this
    
    wx.request({
      url: app.globalData.tomacat + '/user/hdrl', //仅为示例，并非真实的接口地址
      data:{
        tstart:a,
        tend:b
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        for(var i = 0;i<=dataList.length-1;i++){
  
          dataList[i].pictures= JSON.parse(dataList[i].pictures);
          dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
          dataList[i].begintime =  util2.formatTime(dataList[i].begintime);
          dataList[i].endtime =  util2.formatTime(dataList[i].endtime);
        }

        that.setData({
          dataList:dataList,
          loading:false
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
   
  

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.vibrateShort();
    var that = this 
    var x = new Date(that.data.date + ' ' +  that.data.time)
    var tstart = x.getTime();
    console.log(tstart);
    var tend = ((tstart /1000)+24*60*60)*1000
    console.log(tend);

    this.setData({
      tstart:tstart,
      tend:tend
    })
    this.getData()
  },

  getData(){
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/hdrl', //仅为示例，并非真实的接口地址
      data:{
        tstart:that.data.tstart,
        tend:that.data.tend
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        for(var i = 0;i<=dataList.length-1;i++){
  
          dataList[i].pictures= JSON.parse(dataList[i].pictures);
          dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
          dataList[i].begintime =  util2.formatTime(dataList[i].begintime);
          dataList[i].endtime =  util2.formatTime(dataList[i].endtime);
        }

        that.setData({
          dataList:dataList,
          loading:false
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
  },
 
  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})