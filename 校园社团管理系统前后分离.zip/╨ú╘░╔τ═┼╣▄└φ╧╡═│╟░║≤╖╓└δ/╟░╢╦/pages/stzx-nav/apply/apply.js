// pages/stzx-nav/apply/apply.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
   imglist:[]
  },

  chooseImage(){
    var that = this;
    wx.chooseImage({
      count: 6,
      sizeType: ['compressed'],
      sourceType: ['album','camera'],
      success(res){
        console.log(res)
        console.log(res.tempFilePaths)

        if (res.tempFilePaths.length + that.data.imglist.length >6) {
          wx.showToast({
            title: '超过6张',
            icon:'none'
          })
        }else{
          that.setData({
            tempImgList:res.tempFilePaths
          })
           //上传图片
      that.uploadImage(0)

        }

          
      }
    })
  },

  uploadImage(i){
    var that = this
    if (i>= that.data.tempImgList.length) {
      
      return;

    }
   
    wx.uploadFile({
      url: app.globalData.tomacat+ "/user/stzx/uploadimg/apply",
      name:"file",
      filePath: that.data.tempImgList[i], // 小程序临时文件路径
      header: {
        "content-type": "multipart/form-data"
      },
      success: res => {
        // 返回文件 ID
        console.log("上传中",res)

        let list = that.data.imglist.concat(res.data)

         that.setData({
          imglist:list
         })
         
         that.uploadImage(i+1);


      },
      fail:err =>{
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        
      }
      
    })
  },

  deleteImg(e){
    console.log(e.currentTarget.dataset.index)
    this.data.cloudImgList.splice(e.currentTarget.dataset.index,1)
    this.setData({
      cloudImgList: this.data.cloudImgList
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options);
   this.setData({
     id:options.id
   })
  },


  formSubmit(e){
   console.log(e);
   wx.showLoading({
     title: '提交中',
   })
   var that = this
   if (e.detail.value.name.length ==0|| e.detail.value.sex.length==0 || e.detail.value.mianmao.length==0 || e.detail.value.job.length==0||e.detail.value.introduce.length==0) {
     wx.showToast({
       title: '必填项不能为空',
       icon:'error'
     })
   }else{

   
    wx.request({
      url: app.globalData.tomacat + '/user/stzx/apply', //仅为示例，并非真实的接口地址
      data:{
        username:app.globalData.userInfo.username,
        stid:that.data.id,
        name:e.detail.value.name,
        sex:e.detail.value.sex,
        mianmao:e.detail.value.mianmao,
        job:e.detail.value.job,
        introduce:e.detail.value.introduce,
        pictures:that.data.imglist
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)
     wx.showToast({
       title: '提交成功',
       icon:'success',
       duration:500
     })
     setTimeout(function(){
       wx.navigateBack({
         delta: 1,
       })
     },500)
       
      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })


   }
  },


})