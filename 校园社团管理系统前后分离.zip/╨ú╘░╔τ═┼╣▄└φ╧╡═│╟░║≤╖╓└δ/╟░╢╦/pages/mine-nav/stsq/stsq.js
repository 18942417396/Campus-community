// pages/mine-nav/stsq/stsq.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  formSubmit(e){
   console.log(e);
   wx.showLoading({
    title: '注册中',
  })
 
  var that = this
  console.log('form发生了submit事件，携带数据为：', e.detail.value)
  if(e.detail.value.shetuanName.length == 0 || e.detail.value.password.length == 0 || e.detail.value.introduce.length == 0 ||  that.data.tempImgList == null){

    wx.showToast({
      title: '格式错误！',
      icon:'none'
    })
  }else{



    console.log("提交表单成功！");

 

    wx.request({
      url: app.globalData.tomacat + "/user/shetuanregister", 
      data: {
        username:app.globalData.userInfo.username,
        shetuanName: e.detail.value.shetuanName,
        password:e.detail.value.password,
        introduce:e.detail.value.introduce,
        shetuanfaceimg: that.data.tempImgList
      },
      method:'POST',
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      success (res) {
        console.log(res.data)
        if(res.data == 'thisshetuanexit'){
          wx.showToast({
            title: '已有该社团名称',
            icon:'error'
          })

        }else{
          wx.hideLoading({
            success: (res) => {
              wx.showToast({
                title: '提交成功！',
                icon:'success',
                duration:500
              })
              setTimeout(function(){
                wx.navigateBack({
                  delta: 1,
                })
              },500)
            
            },
          })
        }
  
      },
      fail(err){
        wx.showToast({
          title: '服务器出错了！'+err.errMsg,
          icon:'error',
          duration:5000,
        })
      }
    })

  }
 
  },
  chooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album','camera'],
      success(res){
        console.log(res)
        console.log(res.tempFilePaths)
          that.setData({
            tempImgList:res.tempFilePaths[0]
          })
           //上传图片
      that.uploadImage()

          
         
      }
    })
  },
  uploadImage(){
    var that = this
   
    wx.uploadFile({
      url: app.globalData.tomacat+ "/user/faceimg/upload",
      name:"file",
      filePath: that.data.tempImgList, // 小程序临时文件路径
      header: {
        "content-type": "multipart/form-data"
      },
      success: res => {
        // 返回文件 ID
        console.log("上传中",res)
         that.setData({
          tempImgList:res.data
         })
         

         console.log("我的新头像"+that.data.tempImgList);

      },
      fail:err =>{
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        
      }
      
    })
  },



 
})