// pages/mine/mine.js
const app = getApp()
const util = require("../../utils/src");
const util2 = require("../../utils/util")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList:[]
  
  },
  gonews(){
   wx.navigateTo({
     url: '/pages/news/news-index/news-index',
   })
  },
 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.getactive()
   

  },
  getactive(){
    var that = this
    if (app.globalData.userInfo !=null) {
      wx.request({
        url: app.globalData.tomacat + '/user/active/mine/today', //仅为示例，并非真实的接口地址，
        data:{
          username:app.globalData.userInfo.username
        },
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        method:'POST',
        success (res) {
          console.log(res.data)
  
          let dataList = res.data

          for(var i = 0;i<=dataList.length-1;i++){
  
          
            dataList[i].begintime =  util2.formatTime(dataList[i].begintime);
            dataList[i].endtime =  util2.formatTime(dataList[i].endtime);
          }
          
      
  
          that.setData({
            dataList:dataList
          })
  
        
        },
        fail(res){
          wx.showToast({
            title: '访问不到数据',
            icon:'none'
          })
        }
      })
    }
    
  },

  tuichu(){
        var that = this
       wx.removeStorageSync('userInfo')
       app.globalData.userInfo =null
       wx.showToast({
         title: '退出成功',
         icon:'success',
         duration:500
       })
    
       setTimeout(function(){
        that.onShow()
       },500)
      },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log(app.globalData.userInfo);
    this.setData({
      userInfo : app.globalData.userInfo
    })
    this.getnews()


  },

  getnews(){
  var that =this
    if (app.globalData.userInfo !=null) {

      wx.request({
        url: app.globalData.tomacat + "/user/mine/newsget", 
        data: {
          username: app.globalData.userInfo.username
        },
        method:'POST',
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        success (res) {

          if (res.data == 'false') {
            
            that.setData({
              isnew:false
            })
          }else{

            that.setData({
              isnew:true
            })

          }

        
        },
        fail(err){
          wx.showToast({
            title: '服务器出错了！'+err.errMsg,
            icon:'error',
            duration:5000,
          })
        }
      })
      
    }
  },


  gomyactive(){
    if (app.globalData.userInfo ==null) {
      wx.showToast({
        title: '还未登录！',
        icon:'none'
      })
    }else{
      wx.navigateTo({
        url: '/pages/myactive/myactive',
      })
    }
  },
  gomyshetuan(){
    if (app.globalData.userInfo ==null) {
      wx.showToast({
        title: '还未登录！',
        icon:'none'
      })
    }else{
      wx.navigateTo({
        url: '/pages/myshetuan/myshetuan',
      })
    }
  },
  gouserupdate(){
    wx.navigateTo({
      url: '/pages/grxx/grxx',
    })
  },
  goshetuansq(){
    if (app.globalData.userInfo ==null) {
      wx.showToast({
        title: '还未登录！',
        icon:'none'
      })
    }else{
      wx.navigateTo({
        url: '/pages/mine-nav/stsq/stsq',
      })
    }
   
  },

  goactive(e){
    wx.navigateTo({
      url: '/pages/active/active?id='+e.currentTarget.dataset.id,
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    var that = this
    that.setData({
      dataList:[]
    })
    setTimeout(function(){
      that.getactive()
    },500)
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  goauth(){
    wx.navigateTo({
      url: '/pages/auth/auth',
    })
  }
})