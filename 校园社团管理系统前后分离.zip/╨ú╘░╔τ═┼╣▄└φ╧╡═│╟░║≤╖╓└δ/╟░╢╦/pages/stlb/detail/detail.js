// pages/stlb/detail/detail.js
const app = getApp()
const util = require("../../../utils/src")
const util2 = require("../../../utils/util")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingsrc:app.globalData.loading,
    dataList:[],
    active:[],
    loading:true,
    inputvalue:'',
    nav:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      id:options.id
    })
    this.getshetuan()
    this.getData()
    this.getactive()

  },
  goactive(e){
    wx.navigateTo({
      url: '/pages/active/active?id='+e.currentTarget.dataset.id,
    })
  },
  godetail(e){
    wx.navigateTo({
      url: '/pages/detail/detail?id='+e.currentTarget.dataset.id,
    })
  },

  getactive(){
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/stlb/detail/getshetuan/active', //仅为示例，并非真实的接口地址
      data:{
       id:that.data.id
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let list = res.data

        for(var i = 0;i<=list.length-1;i++){

          list[i].pictures= JSON.parse(list[i].pictures);
          list[i].writetime =  util2.formatTime(list[i].writetime);
    
        }

        that.setData({
          active:list,
          loading:false
        })

        console.log("我的活动",that.data.active);
      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })

  },

  getshetuan(){
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/stlb/detail/getshetuan', //仅为示例，并非真实的接口地址
      data:{
       id:that.data.id
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        that.setData({
          shetuan:dataList
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })

  },

  getData(){

    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/stlb/detail', //仅为示例，并非真实的接口地址
      data:{
       id:that.data.id
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        for(var i = 0;i<=dataList.length-1;i++){

          dataList[i].pictures= JSON.parse(dataList[i].pictures);
          dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
    
        }

        that.setData({
          dataList:dataList,
          loading:false
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
  },

  changenav(e){
    var that = this
    console.log(e.currentTarget.dataset.i);
    this.setData({
      nav:e.currentTarget.dataset.i,
      loading:true
    })

      that.onPullDownRefresh()
    
  
   
  },

  gobaoming(){
   wx.navigateTo({
     url: '/pages/stzx-nav/apply/apply?id='+this.data.shetuan.id,
   })
  },

  onPullDownRefresh(){

    var that = this

    if (that.data.nav==0) {
      this.setData({
        dataList:[]
      })
  
      setTimeout(function(){
  
        that.getData()
      },1000)
    }else if(that.data.nav==1){
      this.setData({
        active:[]
      
      })
  
      setTimeout(function(){
  
        that.getactive()
      },1000)
    }
    

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})