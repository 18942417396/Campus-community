// index.js
const util = require("../../utils/src");
const util2 = require("../../utils/util")
// 获取应用实例
const app = getApp()

Page({
  data: {
    dataList:[],
      // 状态栏高度
      statusBarHeight: wx.getStorageSync('statusBarHeight') + 'px',
      // 导航栏高度
      navigationBarHeight: wx.getStorageSync('navigationBarHeight') + 'px',
      // 胶囊按钮高度
      menuButtonHeight: wx.getStorageSync('menuButtonHeight') + 'px',
      // 导航栏和状态栏高度
      navigationBarAndStatusBarHeight:
        wx.getStorageSync('statusBarHeight') +
        wx.getStorageSync('navigationBarHeight') +
        'px',
        loadingsrc:util.loading
    },

    onShareAppMessage(){

    },

    onLoad(){
    
      this.getData()
      
    },
    onPullDownRefresh(){
     var that = this

     that.setData({
       dataList:[],
       loading:true
     })
     setTimeout(function(){
      that.getData()
     },1000)
    },
    getData(){
      var that = this
      wx.request({
        url: app.globalData.tomacat + '/user/tzgl', //仅为示例，并非真实的接口地址
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        method:'GET',
        success (res) {
          console.log(res.data)

          let dataList = res.data

          for(var i = 0;i<=dataList.length-1;i++){
  
            dataList[i].pictures= JSON.parse(dataList[i].pictures);
            dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
      
          }

          that.setData({
            dataList:dataList,
            loading:false
          })

        
        },
        fail(res){
          wx.showToast({
            title: '访问不到数据',
            icon:'none'
          })
        }
      })
    },
    // 链接跳转

    gosttz(){
      wx.switchTab({
        url: '/pages/sttz/sttz',
      })
    },

    gostjj(){
      wx.switchTab({
        url: '/pages/stjj/stjj',
      })
    },

    gosthd(){
      wx.switchTab({
        url: '/pages/hdrl/hdrl',
      })
    },

    gostzc(){
      wx.navigateTo({
        url: '/pages/stzc/stzc',
      })
    },

    gostzx(){
      wx.navigateTo({
        url: '/pages/stzx/stzx',
      })
    },

    gostfl(){
      wx.navigateTo({
        url: '/pages/stlb/index/index',
      })
    },

    godetail(e){
      wx.navigateTo({
        url: '/pages/detail/detail?id='+e.currentTarget.dataset.id,
      })
    }

})
