// pages/sttz/sttz.js
const util = require("../../utils/src");
const util2 = require("../../utils/util")
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingsrc:util.loading,
    dataList:[],
    loading:true,
    inputvalue:''
  },

  getsearch(e){
    this.setData({
      inputvalue:e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
   this.getData()
  },

  getData(){
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/tzgl-sttz/search', //仅为示例，并非真实的接口地址
      data:{
       topic:that.data.inputvalue
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        for(var i = 0;i<=dataList.length-1;i++){

          dataList[i].pictures= JSON.parse(dataList[i].pictures);
          dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
    
        }

        that.setData({
          dataList:dataList,
          loading:false
        })

      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
  },



  onPullDownRefresh(){

    var that = this
    this.setData({
      dataList:[],
      loading:true
    })

    setTimeout(function(){

      that.getData()
    },1000)

  },
  godetail(e){
    wx.navigateTo({
      url: '/pages/detail/detail?id='+e.currentTarget.dataset.id,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})