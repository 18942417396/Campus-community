// pages/detail/sttz_detail/sttz_detail.js
const util = require("../../utils/src");
const util2 = require("../../utils/util")
// 获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    fankuilist:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
   this.setData({
     id:options.id
   })
   this.getdata()
  },

  baoming(){
    var that = this
    wx.showLoading({
      title: '报名中',
    })
   if (app.globalData.userInfo == null) {
      wx.showToast({
        title: '还未登录！',
        icon:'error'
      })
   }else{
    wx.request({
      url: app.globalData.tomacat + '/user/active/baoming/first', //仅为示例，并非真实的接口地址
      data:{
        id:that.data.id,
        username:app.globalData.userInfo.username
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        if (res.data == "success") {
          wx.showToast({
            title: '报名成功！',
            icon:'success'
          })
          
        }else if (res.data == "above") {
          wx.showToast({
            title: '超出报名时间！无法报名',
            icon:'error'
          })
          
        }else{
          wx.showToast({
            title: '您已报名过！',
            icon:'error'
          })
        }
        
      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })

   }
  },

  getdata(){
    
    var that = this
    wx.request({
      url: app.globalData.tomacat + '/user/active/detail', //仅为示例，并非真实的接口地址
      data:{
        id:that.data.id
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

          dataList.pictures= JSON.parse(dataList.pictures);
          dataList.writetime =  util2.formatTime(dataList.writetime);
          dataList.begintime =  util2.formatTime(dataList.begintime);
          dataList.endtime =  util2.formatTime(dataList.endtime);
      
        that.setData({
          dataList:dataList,
        })

        // 获取反馈
     wx.request({
      url: app.globalData.tomacat + '/user/active/fankui/detail', //仅为示例，并非真实的接口地址
      data:{
        activeid:that.data.id,
      },
      header: {
        'Cookie':wx.getStorageSync('cookieKey'),
        'content-type': 'application/json' // 默认值
      },
      method:'POST',
      success (res) {
        console.log(res.data)

        let dataList = res.data

        for(var i = 0;i<=dataList.length-1;i++){

          dataList[i].writetime =  util2.formatTime(dataList[i].writetime);
    
        }
       that.setData({
        fankuilist :dataList
       
       })
      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })
      
      },
      fail(res){
        wx.showToast({
          title: '访问不到数据',
          icon:'none'
        })
      }
    })

     

  },
       // 打开图片
       previewImg(event){
        var that = this;
        console.log(event)
        wx.previewImage({
          current: event.currentTarget.dataset.src,//当前显示图片的路径
          urls: that.data.dataList.pictures,
        })
      },
    
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  showPopup() {
    this.setData({ show: true });
  },

  onClose() {
    this.setData({ show: false });
  },
  getfankui(e){
   this.setData({
     fankui:e.detail.value
   })
  },
  submitfankui(){
    var  that = this
   if (that.data.fankui ==null || that.data.fankui.length==0) {
     wx.showToast({
       title: '内容不能为空',
       icon:'none'
     })
   }else{

    if (app.globalData.userInfo !=null) {
      wx.request({
        url: app.globalData.tomacat + '/user/active/fankui', //仅为示例，并非真实的接口地址
        data:{
          stid:that.data.dataList.stid,
          activeid:that.data.id,
          fankui:that.data.fankui,
          username:app.globalData.userInfo.username
        },
        header: {
          'Cookie':wx.getStorageSync('cookieKey'),
          'content-type': 'application/json' // 默认值
        },
        method:'POST',
        success (res) {
          console.log(res.data)
  
          wx.showToast({
            title: '提交成功！',
            icon:'success'
          })
         that.setData({
           show:false
         })
        
        },
        fail(res){
          wx.showToast({
            title: '访问不到数据',
            icon:'none'
          })
        }
      })
    }else{
      wx.showToast({
        title: '您还未登录',
        icon:'none'
      })
    }
  
   }
  },
})