// pages/news/news-index/news-index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingsrc:app.globalData.loading,
    loading:true,
    dataList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
  this.getnews()
  },
  getnews(){
    var that =this
      if (app.globalData.userInfo !=null) {
  
        wx.request({
          url: app.globalData.tomacat + "/user/grxx/newsget", 
          data: {
            username: app.globalData.userInfo.username
          },
          method:'POST',
          header: {
            'Cookie':wx.getStorageSync('cookieKey'),
            'content-type': 'application/json' // 默认值
          },
          success (res) {
           console.log(res.data);
           var list = res.data
           that.setData({
             dataList:list,
             loading:false
           })
  
          
          },
          fail(err){
            wx.showToast({
              title: '服务器出错了！'+err.errMsg,
              icon:'error',
              duration:5000,
            })
          }
        })
        
      }
    },
 


})