const tomacat = 'http://localhost:8080'
var loading = 'https://756e-uniplannet-7gloqwk1349eae41-1315016759.tcb.qcloud.la/2023-2-8-secondhand500/loading.gif?sign=de9f1b8b60de61bb8bea0bbb9c23e1c7&t=1677121598'

module.exports = {
  tomacat,
  loading
}