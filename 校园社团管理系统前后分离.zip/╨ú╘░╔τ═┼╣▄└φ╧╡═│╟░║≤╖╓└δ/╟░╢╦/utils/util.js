const formatTime = time => {
  const year = 1900+time.year
  const month = time.month + 1
  const day = time.date
  const hour = time.hours
  const minute = time.minutes
  const second = time.seconds

  return `${[year, month, day].map(formatNumber).join('-')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}

module.exports = {
  formatTime
}
// 时间戳转化日期格式 yy-mm-dd hh:mm:ss
// function newFormatTime(timestamp) {
//   var date = getDate(timestamp * 1000);//时间戳为10位需*1000
//   var Y = date.getFullYear() + '-';
//   var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
//   var D = date.getDate() + ' ';
//   var h = date.getHours() + ':';
//   var m = date.getMinutes() + ':';
//   var s = date.getSeconds();
//   return Y + M + D + h + m + s;
// }

// module.exports = {
//   newFormatTime: newFormatTime
// }
